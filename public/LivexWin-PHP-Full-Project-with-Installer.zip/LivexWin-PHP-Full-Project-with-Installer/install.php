<?php
/**
 * LivexWin Platform - 1-Click Interactive Web Installer
 * Sets up MySQL Database, Runs database.sql, Configures Admin Account & config.php
 */
session_start();
$step = isset($_GET['step']) ? (int)$_GET['step'] : 1;
$error = '';
$success = '';

// Step 1: Requirements Check
$phpVersion = phpversion();
$isPhpOk = version_compare($phpVersion, '7.4.0', '>=');
$hasPdo = extension_loaded('pdo') && extension_loaded('pdo_mysql');
$hasMbstring = extension_loaded('mbstring');
$hasCurl = extension_loaded('curl');
$isWritable = is_writable(__DIR__);

// Handle Step 2 Form (Database Test & Install)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'run_install') {
    $dbHost = trim($_POST['db_host'] ?? 'localhost');
    $dbPort = trim($_POST['db_port'] ?? '3306');
    $dbName = trim($_POST['db_name'] ?? '');
    $dbUser = trim($_POST['db_user'] ?? '');
    $dbPass = trim($_POST['db_pass'] ?? '');
    $adminUser = trim($_POST['admin_user'] ?? 'admin');
    $adminPass = trim($_POST['admin_pass'] ?? 'admin123');
    $adminPin  = trim($_POST['admin_pin'] ?? '123456');

    try {
        $dsn = "mysql:host=$dbHost;port=$dbPort;charset=utf8mb4";
        $pdo = new PDO($dsn, $dbUser, $dbPass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]);

        // Create Database if not exists
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbName` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;");
        $pdo->exec("USE `$dbName`;");

        // Read and execute database.sql
        $sqlFile = __DIR__ . '/database.sql';
        if (file_exists($sqlFile)) {
            $sqlContent = file_get_contents($sqlFile);
            $pdo->exec($sqlContent);
        }

        // Insert or update Admin account with custom password
        $hash = password_hash($adminPass, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare("INSERT INTO users (id, username, nickname, phone, password_hash, trx_password, role, balance, vip_level)
            VALUES (1, :usr, 'Super Manager', '01888888888', :hash, :pin, 'superadmin', 999999.00, 10)
            ON DUPLICATE KEY UPDATE password_hash = :hash, trx_password = :pin, username = :usr;");
        $stmt->execute([
            ':usr' => $adminUser,
            ':hash' => $hash,
            ':pin' => $adminPin,
        ]);

        // Update config.php with real DB details
        $configFile = __DIR__ . '/config.php';
        if (file_exists($configFile)) {
            $content = file_get_contents($configFile);
            $content = preg_replace("/define('DB_HOST',.*?);/", "define('DB_HOST', '$dbHost');", $content);
            $content = preg_replace("/define('DB_NAME',.*?);/", "define('DB_NAME', '$dbName');", $content);
            $content = preg_replace("/define('DB_USER',.*?);/", "define('DB_USER', '$dbUser');", $content);
            $content = preg_replace("/define('DB_PASS',.*?);/", "define('DB_PASS', '$dbPass');", $content);
            $content = preg_replace("/define('DB_PORT',.*?);/", "define('DB_PORT', '$dbPort');", $content);
            file_put_contents($configFile, $content);
        }

        // Lock installer
        file_put_contents(__DIR__ . '/.installed', date('Y-m-d H:i:s'));

        header('Location: install.php?step=3');
        exit;
    } catch (Exception $e) {
        $error = "ডাটাবেস কানেকশন বা টেবিল তৈরিতে ত্রুটি: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LivexWin - ১-ক্লিক ওয়েব ইন্সটলার</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>body { font-family: 'Hind Siliguri', sans-serif; }</style>
</head>
<body class="bg-[#0f0203] text-white min-h-screen flex items-center justify-center p-4">
    <div class="max-w-xl w-full bg-[#1b0407] border-2 border-red-700/60 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <!-- Brand Header -->
        <div class="text-center mb-6">
            <div class="inline-flex items-center gap-2 px-4 py-1 rounded-full bg-red-600/30 border border-red-500/50 text-red-300 text-xs font-bold mb-2">
                <span>LIVEXWIN CASINO PLATFORM</span>
            </div>
            <h1 class="text-2xl sm:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-200">
                স্বয়ংক্রিয় ওয়েব ইন্সটলার v2.8.4
            </h1>
            <p class="text-xs text-gray-300 mt-1">ক্যাসিনো ওয়েবসাইট ও অ্যাডমিন প্যানেল ইন্সটলেশন গাইড</p>
        </div>

        <?php if ($error): ?>
            <div class="p-3 mb-4 bg-red-900/80 border border-red-500 text-red-200 text-xs rounded-xl font-bold">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <!-- STEP 1: Requirements Check -->
        <?php if ($step === 1): ?>
            <div class="space-y-4">
                <h3 class="text-sm font-bold text-amber-300 border-b border-white/10 pb-2">১. সার্ভার রিকোয়ারমেন্ট চেক</h3>
                <div class="space-y-2 text-xs">
                    <div class="flex justify-between items-center p-2.5 rounded-xl bg-black/40 border border-white/5">
                        <span>PHP ভার্সন (>= 7.4): <?= $phpVersion ?></span>
                        <span class="font-bold <?= $isPhpOk ? 'text-emerald-400' : 'text-red-400' ?>"><?= $isPhpOk ? '✓ পাস' : '✕ ফেইল' ?></span>
                    </div>
                    <div class="flex justify-between items-center p-2.5 rounded-xl bg-black/40 border border-white/5">
                        <span>PDO & MySQL ড্রাইভার</span>
                        <span class="font-bold <?= $hasPdo ? 'text-emerald-400' : 'text-red-400' ?>"><?= $hasPdo ? '✓ সক্রিয়' : '✕ অনুপস্থিত' ?></span>
                    </div>
                    <div class="flex justify-between items-center p-2.5 rounded-xl bg-black/40 border border-white/5">
                        <span>cURL ও Mbstring এক্সটেনশন</span>
                        <span class="font-bold <?= ($hasCurl && $hasMbstring) ? 'text-emerald-400' : 'text-red-400' ?>"><?= ($hasCurl && $hasMbstring) ? '✓ সক্রিয়' : '✕ অনুপস্থিত' ?></span>
                    </div>
                    <div class="flex justify-between items-center p-2.5 rounded-xl bg-black/40 border border-white/5">
                        <span>ডাইরেক্টরি রাইট পারমিশন (Writable)</span>
                        <span class="font-bold <?= $isWritable ? 'text-emerald-400' : 'text-amber-400' ?>"><?= $isWritable ? '✓ প্রস্তুত' : '! সতর্কবার্তা' ?></span>
                    </div>
                </div>

                <div class="pt-4 flex justify-end">
                    <a href="install.php?step=2" class="px-6 py-3 bg-gradient-to-r from-red-600 via-rose-600 to-red-600 text-white font-extrabold text-xs rounded-xl shadow-lg hover:brightness-110">
                        পরবর্তী ধাপ: ডাটাবেস সেটআপ ›
                    </a>
                </div>
            </div>
        <?php endif; ?>

        <!-- STEP 2: Database Configuration Form -->
        <?php if ($step === 2): ?>
            <form method="POST" action="install.php" class="space-y-3 text-xs">
                <input type="hidden" name="action" value="run_install">
                <h3 class="text-sm font-bold text-amber-300 border-b border-white/10 pb-2">২. MySQL ডাটাবেস ও অ্যাডমিন তথ্য</h3>

                <div class="grid grid-cols-2 gap-2.5">
                    <div>
                        <label class="block font-bold text-gray-300 mb-1">ডাটাবেস হোস্ট:</label>
                        <input type="text" name="db_host" value="localhost" required class="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-white font-mono">
                    </div>
                    <div>
                        <label class="block font-bold text-gray-300 mb-1">পোর্ট:</label>
                        <input type="text" name="db_port" value="3306" required class="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-white font-mono">
                    </div>
                </div>

                <div>
                    <label class="block font-bold text-gray-300 mb-1">ডাটাবেসের নাম (Database Name):</label>
                    <input type="text" name="db_name" placeholder="যেমন: livexwin_db" required class="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-white font-mono">
                </div>

                <div class="grid grid-cols-2 gap-2.5">
                    <div>
                        <label class="block font-bold text-gray-300 mb-1">ডাটাবেস ইউজারনেম:</label>
                        <input type="text" name="db_user" value="root" required class="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-white font-mono">
                    </div>
                    <div>
                        <label class="block font-bold text-gray-300 mb-1">ডাটাবেস পাসওয়ার্ড:</label>
                        <input type="password" name="db_pass" placeholder="পাসওয়ার্ড না থাকলে খালি রাখুন" class="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-white font-mono">
                    </div>
                </div>

                <div class="pt-2 border-t border-white/10">
                    <span class="text-amber-300 font-bold block mb-2">মাস্টার অ্যাডমিন লগইন তথ্য:</span>
                    <div class="grid grid-cols-3 gap-2">
                        <div>
                            <label class="block text-[10px] text-gray-400 mb-0.5">অ্যাডমিন ইউজার:</label>
                            <input type="text" name="admin_user" value="admin" class="w-full bg-black/60 border border-white/10 rounded-lg p-2 text-white font-bold">
                        </div>
                        <div>
                            <label class="block text-[10px] text-gray-400 mb-0.5">পাসওয়ার্ড:</label>
                            <input type="text" name="admin_pass" value="admin123" class="w-full bg-black/60 border border-white/10 rounded-lg p-2 text-white font-bold">
                        </div>
                        <div>
                            <label class="block text-[10px] text-gray-400 mb-0.5">৬ সংখ্যার পিন:</label>
                            <input type="text" name="admin_pin" value="123456" maxlength="6" class="w-full bg-black/60 border border-white/10 rounded-lg p-2 text-white font-mono font-bold">
                        </div>
                    </div>
                </div>

                <div class="pt-4 flex justify-between items-center">
                    <a href="install.php?step=1" class="text-gray-400 hover:text-white">‹ পেছনে</a>
                    <button type="submit" class="px-6 py-3 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 text-black font-black text-xs rounded-xl shadow-lg hover:brightness-110 active:scale-95 cursor-pointer">
                        ইন্সটল ও ডাটাবেস তৈরি করুন ⚡
                    </button>
                </div>
            </form>
        <?php endif; ?>

        <!-- STEP 3: Completed Celebration -->
        <?php if ($step === 3): ?>
            <div class="text-center py-4 space-y-4">
                <div class="w-16 h-16 rounded-full bg-emerald-500/20 border-2 border-emerald-400 text-emerald-400 flex items-center justify-center text-3xl mx-auto shadow-lg">
                    ✓
                </div>
                <h3 class="text-xl font-black text-emerald-400">অভিনন্দন! ইন্সটলেশন সফল হয়েছে!</h3>
                <p class="text-xs text-gray-300">
                    LivexWin এর সকল ডাটাবেস টেবিল, অ্যাডমিন ড্যাশবোর্ড এবং ফ্রন্ট-এন্ড গেম সম্পূর্ণ প্রস্তুত।
                </p>

                <div class="p-3 bg-black/50 rounded-2xl border border-white/10 text-left text-xs space-y-1">
                    <div class="flex justify-between">
                        <span class="text-gray-400">অ্যাডমিন লগইন URL:</span>
                        <span class="text-yellow-300 font-mono font-bold">admin/index.php</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-400">ইউজারনেম:</span>
                        <span class="text-white font-mono font-bold">admin</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-400">উত্তোলন পিন:</span>
                        <span class="text-white font-mono font-bold">123456</span>
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-3 pt-2">
                    <a href="index.php" class="py-3 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-black text-xs rounded-xl shadow-md">
                        হোম পেজে প্রবেশ করুন ›
                    </a>
                    <a href="admin/index.php" class="py-3 bg-gradient-to-r from-amber-400 to-yellow-400 text-black font-black text-xs rounded-xl shadow-md">
                        অ্যাডমিন প্যানেলে যান ›
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
