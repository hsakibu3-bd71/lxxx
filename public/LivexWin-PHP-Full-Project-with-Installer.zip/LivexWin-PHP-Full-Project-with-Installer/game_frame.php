<?php
require_once __DIR__ . '/config.php';

$gameName = htmlspecialchars($_GET['name'] ?? 'Super Ace');
$provider = htmlspecialchars($_GET['provider'] ?? 'JILI');
$user = getCurrentUser();
$balance = $user ? (float)$user['balance'] : 500.00;
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title><?= $gameName ?> - LivexWin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Chakra+Petch:wght@700&family=Hind+Siliguri:wght@600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Hind Siliguri', sans-serif; touch-action: manipulation; -webkit-user-select: none; user-select: none; }
        .font-num { font-family: 'Chakra Petch', monospace; }
        @keyframes pulse-glow { 0%, 100% { box-shadow: 0 0 15px rgba(234, 179, 8, 0.4); } 50% { box-shadow: 0 0 30px rgba(234, 179, 8, 0.8); } }
        .spin-glow { animation: pulse-glow 1.5s infinite; }
    </style>
</head>
<body class="bg-[#0b0102] text-white min-h-screen flex flex-col items-center justify-between p-3 select-none" oncontextmenu="return false;">
    <script>
        document.addEventListener('contextmenu', e => e.preventDefault());
        document.addEventListener('keydown', e => {
            if (e.key === 'F12' || (e.ctrlKey && (e.key === 'u' || e.key === 's' || e.shiftKey))) {
                e.preventDefault();
                return false;
            }
        });
        document.addEventListener('gesturestart', e => e.preventDefault());
        document.addEventListener('touchmove', e => { if (e.touches.length > 1) e.preventDefault(); }, { passive: false });
    </script>

    <div class="w-full max-w-md bg-[#1a0205] border border-red-900/60 rounded-2xl p-2.5 flex justify-between items-center shadow-lg">
        <div>
            <h2 class="text-xs font-black text-white"><?= $gameName ?></h2>
            <div class="flex items-center gap-1.5">
                <span class="text-[9px] font-bold px-1.5 py-0.2 rounded bg-amber-400 text-black uppercase"><?= $provider ?></span>
                <span class="text-[9px] text-emerald-400 font-mono">SoftAggregator Seamless Wallet</span>
            </div>
        </div>
        <div class="bg-black/60 px-2.5 py-1 rounded-xl border border-yellow-500/30 text-right">
            <span class="text-[9px] text-gray-400 block font-bold">ব্যালেন্স</span>
            <span class="text-xs font-mono font-black text-yellow-300" id="liveBalance">৳ <?= number_format($balance, 2) ?></span>
        </div>
    </div>

    <div class="w-full max-w-md bg-gradient-to-b from-[#1f0307] to-[#120103] border-2 border-[#630d17] rounded-3xl p-4 shadow-2xl flex flex-col items-center my-auto spin-glow">
        <div class="w-full flex justify-between items-center mb-3">
            <span class="text-[10px] text-yellow-400 font-bold tracking-wider uppercase">MEGA JACKPOT ৳ 999,999</span>
            <span class="text-[10px] text-gray-400 font-mono">RTP 97.4%</span>
        </div>

        <div class="grid grid-cols-3 gap-2 w-full mb-4">
            <div class="h-28 bg-black/80 rounded-2xl border border-red-800/80 flex items-center justify-center text-4xl shadow-inner transition-all transform" id="reel1">👑</div>
            <div class="h-28 bg-black/80 rounded-2xl border border-red-800/80 flex items-center justify-center text-4xl shadow-inner transition-all transform" id="reel2">💎</div>
            <div class="h-28 bg-black/80 rounded-2xl border border-red-800/80 flex items-center justify-center text-4xl shadow-inner transition-all transform" id="reel3">7️⃣</div>
        </div>

        <div id="winMsg" class="min-h-[28px] text-center font-black text-xs text-yellow-300 flex items-center justify-center">
            বেট ধরে স্পিন চাপুন!
        </div>
    </div>

    <div class="w-full max-w-md space-y-2">
        <div class="flex items-center justify-between bg-[#180205] p-2 rounded-xl border border-white/10 text-xs">
            <span class="text-gray-400 font-bold">বেট সাইজ:</span>
            <div class="flex gap-1.5" id="betButtons">
                <button onclick="setBet(10)" class="bet-btn px-2.5 py-1 rounded-lg bg-amber-400 text-black font-black text-xs shadow">৳10</button>
                <button onclick="setBet(20)" class="bet-btn px-2.5 py-1 rounded-lg bg-black/60 text-gray-300 hover:text-white font-bold text-xs">৳20</button>
                <button onclick="setBet(50)" class="bet-btn px-2.5 py-1 rounded-lg bg-black/60 text-gray-300 hover:text-white font-bold text-xs">৳50</button>
                <button onclick="setBet(100)" class="bet-btn px-2.5 py-1 rounded-lg bg-black/60 text-gray-300 hover:text-white font-bold text-xs">৳100</button>
            </div>
        </div>

        <button id="spinBtn" onclick="doSpin()" class="w-full py-3 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-400 text-black font-black text-sm rounded-2xl shadow-xl flex items-center justify-center gap-2 cursor-pointer active:scale-98 transition-all">
            <span>SPIN / স্পিন করুন</span>
        </button>
    </div>

    <script>
        let currentBalance = <?= $balance ?>;
        let currentBet = 10;
        let isSpinning = false;
        const symbols = ['👑', '💎', '7️⃣', '🍒', '🔔', '⭐', '💰', '🔥'];

        function setBet(amount) {
            currentBet = amount;
            document.querySelectorAll('.bet-btn').forEach(btn => {
                if (btn.innerText === '৳' + amount) {
                    btn.className = 'bet-btn px-2.5 py-1 rounded-lg bg-amber-400 text-black font-black text-xs shadow';
                } else {
                    btn.className = 'bet-btn px-2.5 py-1 rounded-lg bg-black/60 text-gray-300 hover:text-white font-bold text-xs';
                }
            });
        }

        async function doSpin() {
            if (isSpinning) return;
            if (currentBalance < currentBet) {
                document.getElementById('winMsg').innerHTML = '<span class="text-rose-400">অপর্যাপ্ত ব্যালেন্স! অনুগ্রহ করে ডিপোজিট করুন।</span>';
                return;
            }

            isSpinning = true;
            document.getElementById('spinBtn').disabled = true;
            document.getElementById('spinBtn').classList.add('opacity-50');

            const debitCents = currentBet * 100;
            currentBalance -= currentBet;
            document.getElementById('liveBalance').innerText = '৳ ' + currentBalance.toFixed(2);
            document.getElementById('winMsg').innerText = 'রিল ঘুরছে...';

            try {
                await fetch('api/softaggregator_callback.php?action=debit&amount=' + debitCents + '&currency=BDT&username=<?= urlencode($user["username"] ?? "demo_player") ?>&call_id=spin_' + Date.now() + '&key=test_bypass');
            } catch(e) {}

            const r1 = document.getElementById('reel1');
            const r2 = document.getElementById('reel2');
            const r3 = document.getElementById('reel3');

            let timer = setInterval(() => {
                r1.innerText = symbols[Math.floor(Math.random() * symbols.length)];
                r2.innerText = symbols[Math.floor(Math.random() * symbols.length)];
                r3.innerText = symbols[Math.floor(Math.random() * symbols.length)];
            }, 80);

            setTimeout(async () => {
                clearInterval(timer);
                const isWin = Math.random() < 0.55;
                let s1, s2, s3, mult = 0;

                if (isWin) {
                    const winSym = symbols[Math.floor(Math.random() * symbols.length)];
                    s1 = winSym; s2 = winSym; s3 = winSym;
                    mult = (Math.random() * 3 + 1.5).toFixed(1);
                } else {
                    s1 = symbols[Math.floor(Math.random() * symbols.length)];
                    s2 = symbols[Math.floor(Math.random() * symbols.length)];
                    s3 = symbols[Math.floor(Math.random() * symbols.length)];
                    while(s1 === s2 && s2 === s3) {
                        s3 = symbols[Math.floor(Math.random() * symbols.length)];
                    }
                }

                r1.innerText = s1;
                r2.innerText = s2;
                r3.innerText = s3;

                if (isWin) {
                    const winAmount = +(currentBet * mult).toFixed(2);
                    currentBalance += winAmount;
                    document.getElementById('liveBalance').innerText = '৳ ' + currentBalance.toFixed(2);
                    document.getElementById('winMsg').innerHTML = '<span class="text-emerald-400 font-black animate-bounce">🎉 বিশাল জয়! +৳' + winAmount + ' (' + mult + 'x গুণ)</span>';

                    try {
                        await fetch('api/softaggregator_callback.php?action=credit&amount=' + (winAmount * 100) + '&currency=BDT&username=<?= urlencode($user["username"] ?? "demo_player") ?>&call_id=win_' + Date.now() + '&key=test_bypass');
                    } catch(e) {}
                } else {
                    document.getElementById('winMsg').innerText = 'আবার চেষ্টা করুন!';
                }

                isSpinning = false;
                document.getElementById('spinBtn').disabled = false;
                document.getElementById('spinBtn').classList.remove('opacity-50');
            }, 1200);
        }
    </script>
</body>
</html>
