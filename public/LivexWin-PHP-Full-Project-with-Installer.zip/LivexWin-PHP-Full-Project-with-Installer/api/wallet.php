<?php
require_once __DIR__ . '/../config.php';

$user = getCurrentUser();
if (!$user) {
    jsonResponse(['success' => false, 'message' => 'লগইন প্রয়োজন।'], 401);
}

$action = $_GET['action'] ?? ($_POST['action'] ?? '');
$db = getDB();

// 1. SUBMIT DEPOSIT
if ($action === 'deposit') {
    $data = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $amount = (float)($data['amount'] ?? 0);
    $method = trim($data['method'] ?? 'nagad');
    $channel = trim($data['channel'] ?? 'TKPAYBDT');
    $senderPhone = trim($data['senderPhone'] ?? '');
    $trxId = trim($data['trxId'] ?? '');

    if ($amount < 100 || $amount > 50000) {
        jsonResponse(['success' => false, 'message' => 'ডিপোজিটের পরিমাণ ৳১০০ থেকে ৳৫০,০০০ এর মধ্যে হতে হবে।']);
    }

    $txId = 'DEP-' . time() . '-' . rand(100, 999);
    $stmt = $db->prepare("INSERT INTO transactions (id, user_id, type, amount, status, method, channel, account_number, trx_id, note)
        VALUES (?, ?, 'deposit', ?, 'approved', ?, ?, ?, ?, ?)");
    $stmt->execute([$txId, $user['id'], $amount, $method, $channel, $senderPhone, strtoupper($trxId), "$method ডিপোজিট ($channel)"]);

    // Auto credit for seamless demo or configure as pending
    $db->prepare("UPDATE users SET balance = balance + ?, vip_points = vip_points + ? WHERE id = ?")
       ->execute([$amount, (int)($amount / 10), $user['id']]);

    jsonResponse(['success' => true, 'message' => "৳ " . number_format($amount) . " সফলভাবে জমা হয়েছে!"]);
}

// 2. SUBMIT WITHDRAWAL (Strict 6-digit withdrawal PIN check)
if ($action === 'withdraw') {
    $data = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $amount = (float)($data['amount'] ?? 0);
    $method = trim($data['method'] ?? 'nagad');
    $accountNumber = trim($data['accountNumber'] ?? '');
    $trxPass = trim($data['trxPass'] ?? '');

    // Fetch user with withdrawal PIN
    $stmt = $db->prepare("SELECT trx_password, trx_password_set, balance FROM users WHERE id = ? LIMIT 1");
    $stmt->execute([$user['id']]);
    $uRow = $stmt->fetch();

    if (!$uRow['trx_password_set'] || empty($uRow['trx_password'])) {
        jsonResponse(['success' => false, 'message' => 'উত্তোলন করার পূর্বে দয়া করে সদস্য কেন্দ্র -> নিরাপত্তা থেকে আপনার ৬ সংখ্যার উত্তোলন পাসওয়ার্ড সেট করুন।']);
    }

    if ($trxPass !== $uRow['trx_password']) {
        jsonResponse(['success' => false, 'message' => 'ভুল উত্তোলন পাসওয়ার্ড! সঠিক পাসওয়ার্ড দিন।']);
    }

    if (empty($accountNumber)) {
        jsonResponse(['success' => false, 'message' => 'দয়া করে আমার কার্ড থেকে একটি নম্বর নির্বাচন করুন।']);
    }

    if ($amount < 100 || $amount > 25000) {
        jsonResponse(['success' => false, 'message' => 'উত্তোলনের পরিমাণ ৳ ১০০ থেকে ৳ ২৫,০০০ এর মধ্যে হতে হবে।']);
    }

    if ($uRow['balance'] < $amount) {
        jsonResponse(['success' => false, 'message' => 'ওয়ালেটে পর্যাপ্ত ব্যালেন্স নেই।']);
    }

    // Deduct and create pending transaction
    $db->prepare("UPDATE users SET balance = balance - ? WHERE id = ?")->execute([$amount, $user['id']]);

    $txId = 'WD-' . time() . '-' . rand(100, 999);
    $stmt = $db->prepare("INSERT INTO transactions (id, user_id, type, amount, status, method, account_number, note)
        VALUES (?, ?, 'withdraw', ?, 'pending', ?, ?, ?)");
    $stmt->execute([$txId, $user['id'], $amount, $method, $accountNumber, "$method নম্বর: " . maskAccountNumber($accountNumber)]);

    jsonResponse(['success' => true, 'message' => 'উত্তোলন অনুরোধ গৃহীত হয়েছে! অ্যাডমিন অনুমোদনের পর অর্থ আপনার নম্বরে পৌঁছাবে।']);
}

// 3. TRANSACTIONS LIST
if ($action === 'transactions') {
    $stmt = $db->prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 50");
    $stmt->execute([$user['id']]);
    $list = $stmt->fetchAll();
    jsonResponse(['success' => true, 'transactions' => $list]);
}

jsonResponse(['success' => false, 'message' => 'Invalid wallet action.']);
