<?php
require_once __DIR__ . '/../config.php';

$action = $_GET['action'] ?? ($_POST['action'] ?? '');
$db = getDB();

if (!$db) {
    jsonResponse(['success' => false, 'message' => 'ডাটাবেস কানেকশন পাওয়া যায়নি।'], 500);
}

// 1. REGISTER
if ($action === 'register') {
    $data = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $username = trim($data['username'] ?? '');
    $phone = trim($data['phone'] ?? '');
    $password = trim($data['password'] ?? '');

    if (empty($username) || empty($password)) {
        jsonResponse(['success' => false, 'message' => 'ইউজারনেম ও পাসওয়ার্ড প্রয়োজন।']);
    }

    // Check existing
    $stmt = $db->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
    $stmt->execute([$username]);
    if ($stmt->fetch()) {
        jsonResponse(['success' => false, 'message' => 'এই ইউজারনেম ইতিমধ্যে ব্যবহৃত হয়েছে।']);
    }

    $hash = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $db->prepare("INSERT INTO users (username, nickname, phone, password_hash, trx_password, balance, vip_level) VALUES (?, ?, ?, ?, '123456', 500.00, 1)");
    $stmt->execute([$username, $username, $phone ?: '01700000000', $hash]);
    $newId = $db->lastInsertId();

    $_SESSION['user_id'] = $newId;
    $user = getCurrentUser();
    jsonResponse(['success' => true, 'message' => 'সফলভাবে রেজিস্ট্রেশন সম্পন্ন হয়েছে!', 'user' => $user]);
}

// 2. LOGIN
if ($action === 'login') {
    $data = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $username = trim($data['username'] ?? '');
    $password = trim($data['password'] ?? '');

    $stmt = $db->prepare("SELECT id, password_hash, status FROM users WHERE username = ? LIMIT 1");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        jsonResponse(['success' => false, 'message' => 'ইউজারনেম বা পাসওয়ার্ড সঠিক নয়।']);
    }

    if ($user['status'] === 'banned') {
        jsonResponse(['success' => false, 'message' => 'আপনার অ্যাকাউন্ট সাময়িকভাবে স্থগিত করা হয়েছে।']);
    }

    $_SESSION['user_id'] = $user['id'];
    jsonResponse(['success' => true, 'message' => 'লগইন সফল হয়েছে!', 'user' => getCurrentUser()]);
}

// 3. GOOGLE SIGN-IN
if ($action === 'google_login') {
    $data = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $email = trim($data['email'] ?? 'google_user@gmail.com');
    $name = trim($data['name'] ?? 'Google Player');
    $uname = explode('@', $email)[0];

    $stmt = $db->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
    $stmt->execute([$uname]);
    $existing = $stmt->fetch();

    if ($existing) {
        $_SESSION['user_id'] = $existing['id'];
    } else {
        $hash = password_hash('google_oauth_pass', PASSWORD_BCRYPT);
        $stmt = $db->prepare("INSERT INTO users (username, nickname, phone, password_hash, balance, vip_level) VALUES (?, ?, '01712062485', ?, 500.00, 1)");
        $stmt->execute([$uname, $name, $hash]);
        $_SESSION['user_id'] = $db->lastInsertId();
    }

    jsonResponse(['success' => true, 'message' => 'গুগল দিয়ে সফলভাবে লগইন হয়েছে!', 'user' => getCurrentUser()]);
}

// 4. ME / CURRENT USER
if ($action === 'me') {
    $user = getCurrentUser();
    jsonResponse(['success' => true, 'user' => $user]);
}

// 5. LOGOUT
if ($action === 'logout') {
    session_destroy();
    jsonResponse(['success' => true, 'message' => 'লগআউট সফল হয়েছে।']);
}

jsonResponse(['success' => false, 'message' => 'Invalid action.']);
