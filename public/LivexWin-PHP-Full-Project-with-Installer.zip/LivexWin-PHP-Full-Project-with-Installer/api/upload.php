<?php
/**
 * LivexWin Media Upload API Endpoint
 * Handles image file uploads with validation (size, MIME, extensions)
 * Saves to uploads/ directory and returns JSON: {"success": true, "url": "uploads/..."}
 */
require_once __DIR__ . '/../config.php';

header('Content-Type: application/json; charset=utf-8');

$user = getCurrentUser();
if (!$user) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'অননুমোদিত অ্যাক্সেস। অনুগ্রহ করে লগইন করুন।']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'কেবলমাত্র POST মেথড সমর্থিত।']);
    exit;
}

$fileKey = null;
if (isset($_FILES['file'])) $fileKey = 'file';
elseif (isset($_FILES['image'])) $fileKey = 'image';
elseif (isset($_FILES['banner_file'])) $fileKey = 'banner_file';
elseif (isset($_FILES['game_file'])) $fileKey = 'game_file';
elseif (isset($_FILES['site_logo_file'])) $fileKey = 'site_logo_file';

if (!$fileKey || !isset($_FILES[$fileKey]) || $_FILES[$fileKey]['error'] !== UPLOAD_ERR_OK) {
    $errCode = isset($_FILES[$fileKey]['error']) ? $_FILES[$fileKey]['error'] : 'no_file';
    echo json_encode(['success' => false, 'error' => "ফাইল আপলোড ব্যর্থ হয়েছে (কোড: $errCode)"]);
    exit;
}

$fileUrl = saveUploadedImage($fileKey, 'uploads');
if ($fileUrl) {
    echo json_encode([
        'success' => true,
        'url' => $fileUrl,
        'message' => 'ফাইল সফলভাবে আপলোড হয়েছে!'
    ]);
} else {
    echo json_encode([
        'success' => false,
        'error' => 'অবৈধ ফাইল ফরম্যাট বা সাইজ বেশি (অনুমোদিত: JPG, JPEG, PNG, WEBP, GIF, SVG - সর্বোচ্চ 10MB)'
    ]);
}
exit;
