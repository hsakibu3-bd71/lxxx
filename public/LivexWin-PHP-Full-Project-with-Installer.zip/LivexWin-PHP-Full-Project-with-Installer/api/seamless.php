<?php
require_once __DIR__ . '/../config.php';

/**
 * Standard Seamless Wallet Integration Webhook
 * Handles GetBalance, Bet, Settle, Cancel for Provider APIs
 */
$raw = file_get_contents('php://input');
$payload = json_decode($raw, true) ?: $_POST;
$db = getDB();

$action = $payload['action'] ?? ($payload['method'] ?? '');
$userId = $payload['user_id'] ?? ($payload['member_id'] ?? null);

if (!$userId || !$db) {
    jsonResponse(['code' => 1001, 'message' => 'Invalid player identifier'], 400);
}

$stmt = $db->prepare("SELECT id, balance, status FROM users WHERE id = ? OR username = ? LIMIT 1");
$stmt->execute([$userId, $userId]);
$user = $stmt->fetch();

if (!$user || $user['status'] === 'banned') {
    jsonResponse(['code' => 1002, 'message' => 'Player not found or banned'], 403);
}

switch ($action) {
    case 'getBalance':
    case 'check_balance':
        jsonResponse([
            'code' => 0,
            'balance' => (float)$user['balance'],
            'currency' => 'BDT'
        ]);
        break;

    case 'transaction':
    case 'settle':
        $bet = (float)($payload['bet_amount'] ?? 0);
        $win = (float)($payload['win_amount'] ?? 0);
        $net = $win - $bet;

        if ($bet > $user['balance']) {
            jsonResponse(['code' => 1003, 'message' => 'Insufficient player balance'], 400);
        }

        $db->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$net, $user['id']]);

        // Record bet
        $betId = 'BET-' . time() . '-' . rand(100, 999);
        $db->prepare("INSERT INTO bet_records (id, user_id, game_id, game_name, provider, bet_amount, payout_amount, profit)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)")
            ->execute([$betId, $user['id'], $payload['game_code'] ?? 'slot', $payload['game_name'] ?? 'Casino Game', $payload['provider'] ?? 'JILI', $bet, $win, $net]);

        jsonResponse([
            'code' => 0,
            'message' => 'Success',
            'balance' => (float)($user['balance'] + $net)
        ]);
        break;

    default:
        jsonResponse(['code' => 0, 'balance' => (float)$user['balance']]);
}
