<?php
require_once __DIR__ . '/../config.php';

$user = getCurrentUser();
if (!$user) {
    jsonResponse(['success' => false, 'message' => 'লগইন প্রয়োজন।'], 401);
}

$action = $_GET['action'] ?? 'list';
$db = getDB();

// 1. GET BETTING HISTORY (Filter by all/win/loss)
if ($action === 'list') {
    $filter = $_GET['filter'] ?? 'all';
    $sql = "SELECT * FROM bet_records WHERE user_id = ?";
    $params = [$user['id']];

    if ($filter === 'win') {
        $sql .= " AND profit > 0";
    } elseif ($filter === 'loss') {
        $sql .= " AND profit <= 0";
    }
    $sql .= " ORDER BY created_at DESC LIMIT 100";

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $bets = $stmt->fetchAll();

    // Turnover summary
    $sumStmt = $db->prepare("SELECT SUM(bet_amount) as total_bet, SUM(payout_amount) as total_payout FROM bet_records WHERE user_id = ?");
    $sumStmt->execute([$user['id']]);
    $totals = $sumStmt->fetch();

    jsonResponse([
        'success' => true,
        'bets' => $bets,
        'summary' => [
            'total_bet' => (float)($totals['total_bet'] ?? 0),
            'total_payout' => (float)($totals['total_payout'] ?? 0),
        ]
    ]);
}

// 2. RECORD NEW BET (From game spin / round)
if ($action === 'record') {
    $data = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $gameId = trim($data['game_id'] ?? 'jl_super_ace');
    $gameName = trim($data['game_name'] ?? 'Super Ace');
    $provider = trim($data['provider'] ?? 'JILI');
    $betAmount = (float)($data['bet_amount'] ?? 10);
    $payoutAmount = (float)($data['payout_amount'] ?? 0);
    $multiplier = (float)($data['multiplier'] ?? 0);
    $profit = $payoutAmount - $betAmount;

    $betId = 'BET-' . time() . '-' . rand(100, 999);
    $stmt = $db->prepare("INSERT INTO bet_records (id, user_id, game_id, game_name, provider, bet_amount, payout_amount, profit, multiplier)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$betId, $user['id'], $gameId, $gameName, $provider, $betAmount, $payoutAmount, $profit, $multiplier]);

    // Update balance
    $db->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$profit, $user['id']]);

    jsonResponse(['success' => true, 'bet_id' => $betId, 'profit' => $profit]);
}

jsonResponse(['success' => false, 'message' => 'Invalid betting action.']);
