<?php
require_once __DIR__ . '/../config.php';

$user = getCurrentUser();
if (!$user) {
    jsonResponse(['success' => false, 'message' => 'লগইন প্রয়োজন।'], 401);
}

$action = $_GET['action'] ?? ($_POST['action'] ?? 'list');
$db = getDB();

// 1. LIST CARDS
if ($action === 'list') {
    $stmt = $db->prepare("SELECT id, type, account_name, account_number, is_locked, created_at FROM bound_wallets WHERE user_id = ? ORDER BY id ASC");
    $stmt->execute([$user['id']]);
    $cards = $stmt->fetchAll();

    // Format with masked numbers
    foreach ($cards as &$c) {
        $c['masked_number'] = maskAccountNumber($c['account_number']);
    }
    jsonResponse(['success' => true, 'cards' => $cards]);
}

// 2. BIND NEW CARD (Max 5, permanently locked)
if ($action === 'bind') {
    $data = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $type = trim($data['type'] ?? 'nagad');
    $name = trim($data['account_name'] ?? '');
    $number = trim($data['account_number'] ?? '');

    if (empty($name) || empty($number)) {
        jsonResponse(['success' => false, 'message' => 'অ্যাকাউন্টের নাম ও মোবাইল নম্বর পূরণ করুন।']);
    }

    if (strlen($number) < 11) {
        jsonResponse(['success' => false, 'message' => 'সঠিক ১১ সংখ্যার মোবাইল নম্বর দিন।']);
    }

    // Check count
    $stmt = $db->prepare("SELECT COUNT(*) as cnt FROM bound_wallets WHERE user_id = ?");
    $stmt->execute([$user['id']]);
    $row = $stmt->fetch();
    if ($row['cnt'] >= 5) {
        jsonResponse(['success' => false, 'message' => 'সর্বোচ্চ ৫টি নম্বর যুক্ত করা সম্ভব। নিরাপত্তার স্বার্থে এর বেশি নম্বর যুক্ত বা পরিবর্তন করা যাবে না।']);
    }

    $stmt = $db->prepare("INSERT INTO bound_wallets (user_id, type, account_name, account_number, is_locked) VALUES (?, ?, ?, ?, 1)");
    $stmt->execute([$user['id'], $type, $name, $number]);

    jsonResponse(['success' => true, 'message' => 'নম্বরটি সফলভাবে স্থায়ীভাবে সংরক্ষিত ও লক করা হয়েছে!']);
}

// Deleting or Editing is strictly rejected per security rule
if ($action === 'delete' || $action === 'edit') {
    jsonResponse(['success' => false, 'message' => 'নিরাপত্তার স্বার্থে সংরক্ষিত অ্যাকাউন্ট পরিবর্তন বা মুছে ফেলা অনুমোদিত নয়।']);
}

jsonResponse(['success' => false, 'message' => 'Invalid card action.']);
