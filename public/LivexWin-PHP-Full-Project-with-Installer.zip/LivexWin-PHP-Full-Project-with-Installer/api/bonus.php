<?php
require_once __DIR__ . '/../config.php';

$user = getCurrentUser();
if (!$user) {
    jsonResponse(['success' => false, 'message' => 'লগইন প্রয়োজন।'], 401);
}

$action = $_GET['action'] ?? ($_POST['action'] ?? '');
$db = getDB();
$settings = getSiteSettings();

// 1. GOLDEN EGG CRACK
// User requirements:
// Max display: 99,999 ৳
// 3 tiers: ৳9, ৳99, ৳199 based on VIP level
// VIP 1-4: ৳9
// VIP 5-10: ৳99
// VIP 11+: ৳199
if ($action === 'golden_egg') {
    if ($user['golden_eggs_left'] <= 0) {
        jsonResponse(['success' => false, 'message' => 'আজকের জন্য কোনো গোল্ডেন এগ অবশিষ্ট নেই।']);
    }

    $vip = (int)$user['vip_level'];
    $tier1 = (int)($settings['golden_egg_tier1'] ?? 9);
    $tier2 = (int)($settings['golden_egg_tier2'] ?? 99);
    $tier3 = (int)($settings['golden_egg_tier3'] ?? 199);

    if ($vip >= 1 && $vip <= 4) {
        $amount = $tier1;
    } elseif ($vip >= 5 && $vip <= 10) {
        $amount = $tier2;
    } else {
        $amount = $tier3;
    }

    $db->prepare("UPDATE users SET balance = balance + ?, golden_eggs_left = golden_eggs_left - 1 WHERE id = ?")
       ->execute([$amount, $user['id']]);

    $txId = 'EGG-' . time() . '-' . rand(100, 999);
    $db->prepare("INSERT INTO transactions (id, user_id, type, amount, status, note) VALUES (?, ?, 'bonus', ?, 'completed', ?)")
       ->execute([$txId, $user['id'], $amount, "গোল্ডেন এগ ভাঙার পুরস্কার ৳$amount (VIP লেভেল $vip)"]);

    jsonResponse(['success' => true, 'amount' => $amount, 'message' => "দারুণ! গোল্ডেন এগ ভেঙে আপনি ৳$amount পেয়েছেন!"]);
}

// 2. RED PACKET (Max 17 daily)
if ($action === 'red_packet') {
    $maxLimit = (int)($settings['red_packet_daily_limit'] ?? 17);
    if ($user['red_packets_claimed'] >= $maxLimit) {
        jsonResponse(['success' => false, 'message' => "আজকের সব $maxLimit টি রেড প্যাকেট গ্রহণ শেষ!"]);
    }

    $amount = rand(10, 120);
    $db->prepare("UPDATE users SET balance = balance + ?, red_packets_claimed = red_packets_claimed + 1 WHERE id = ?")
       ->execute([$amount, $user['id']]);

    $txId = 'RP-' . time() . '-' . rand(100, 999);
    $db->prepare("INSERT INTO transactions (id, user_id, type, amount, status, note) VALUES (?, ?, 'bonus', ?, 'completed', ?)")
       ->execute([$txId, $user['id'], $amount, "রেড প্যাকেট রিওয়ার্ড ৳$amount"]);

    jsonResponse(['success' => true, 'amount' => $amount, 'message' => "রেড প্যাকেট থেকে আপনি ৳$amount পেয়েছেন!"]);
}

// 3. LUCKY SPIN WHEEL
if ($action === 'wheel') {
    $vip = (int)$user['vip_level'];
    $tier1 = (int)($settings['wheel_tier1'] ?? 8);
    $tier2 = (int)($settings['wheel_tier2'] ?? 88);
    $tier3 = (int)($settings['wheel_tier3'] ?? 1888);

    if ($vip >= 1 && $vip <= 4) {
        $amount = $tier1;
        $prize = "৳ $amount ক্যাশ ড্র";
    } elseif ($vip >= 5 && $vip <= 10) {
        $amount = $tier2;
        $prize = "৳ $amount লাকি ক্যাশ";
    } else {
        $amount = $tier3;
        $prize = "৳ " . number_format($amount) . " মেগা ড্র";
    }

    $db->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$amount, $user['id']]);

    $txId = 'WHEEL-' . time() . '-' . rand(100, 999);
    $db->prepare("INSERT INTO transactions (id, user_id, type, amount, status, note) VALUES (?, ?, 'bonus', ?, 'completed', ?)")
       ->execute([$txId, $user['id'], $amount, "লাকি স্পিন হুইল ড্র: $prize"]);

    jsonResponse(['success' => true, 'prize' => $prize, 'amount' => $amount, 'message' => "অভিনন্দন! স্পিন হুইল থেকে আপনি $prize জিতেছেন!"]);
}

// 4. RESCUE RELIEF FUND (উদ্ধার তহবিল)
if ($action === 'rescue_fund') {
    $maxRelief = (float)($settings['rescue_fund_daily_max'] ?? 500.00);
    $relief = min(50.00, $maxRelief);

    $db->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$relief, $user['id']]);

    $txId = 'RESCUE-' . time() . '-' . rand(100, 999);
    $db->prepare("INSERT INTO transactions (id, user_id, type, amount, status, note) VALUES (?, ?, 'bonus', ?, 'completed', ?)")
       ->execute([$txId, $user['id'], $relief, "উদ্ধার তহবিল (Rescue Relief Cashback)"]);

    jsonResponse(['success' => true, 'amount' => $relief, 'message' => "উদ্ধার তহবিল থেকে আপনার ওয়ালেটে ৳$relief যোগ করা হয়েছে!"]);
}

jsonResponse(['success' => false, 'message' => 'Invalid bonus action.']);
