<?php
/**
 * SoftAggregator Casino Games API Client
 * PDF Documentation: https://api.softaggregator.com/api/v1
 * 40,000+ Casino Games, Seamless Wallet Integration
 */
require_once __DIR__ . '/../config.php';

class SoftAggregatorAPI {
    private string $baseUrl = 'https://api.softaggregator.com/api/v1';
    private string $apiLogin;
    private string $apiPassword;
    private string $saltKey;
    private string $currency;

    public function __construct(?string $apiLogin = null, ?string $apiPassword = null, ?string $saltKey = null) {
        $settings = getSiteSettings();
        $this->apiLogin = $apiLogin ?: ($settings['softaggregator_api_login'] ?? 'DEMO_LIVEXWIN_LOGIN');
        $this->apiPassword = $apiPassword ?: ($settings['softaggregator_api_password'] ?? 'DEMO_LIVEXWIN_PASS');
        $this->saltKey = $saltKey ?: ($settings['softaggregator_salt_key'] ?? 'LXW_SALT_KEY_88273619');
        $this->currency = $settings['softaggregator_currency'] ?? 'BDT';
    }

    public function request(string $method, array $extra = []): array {
        $payload = array_merge([
            'api_login' => $this->apiLogin,
            'api_password' => $this->apiPassword,
            'method' => $method,
        ], $extra);

        $ch = curl_init($this->baseUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json; charset=utf-8']);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);

        $response = curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);

        if ($err) {
            return ['error' => 1, 'message' => 'cURL Error: ' . $err];
        }

        $decoded = json_decode($response, true);
        return is_array($decoded) ? $decoded : ['error' => 1, 'message' => 'Invalid JSON from SoftAggregator', 'raw' => $response];
    }

    public function getCurrencies(): array {
        return $this->request('getCurrencies');
    }

    public function getGameList(): array {
        return $this->request('getGameList');
    }

    public function getProviderList(): array {
        return $this->request('getProviderList');
    }

    public function createPlayer(string $username, string $password = 'secret', ?string $currency = null): array {
        return $this->request('createPlayer', [
            'user_username' => $username,
            'user_password' => $password,
            'currency' => $currency ?: $this->currency,
        ]);
    }

    public function getGame(string $username, string $password, string $gameIdHash, bool $isMobile = true, string $lang = 'bn', ?string $currency = null, string $country = 'BD', ?string $homeUrl = null): array {
        return $this->request('getGame', [
            'user_username' => $username,
            'user_password' => $password,
            'gameid' => $gameIdHash,
            'lang' => $lang,
            'currency' => $currency ?: $this->currency,
            'device' => $isMobile ? 'mobile' : 'desktop',
            'country' => $country,
            'homeurl' => $homeUrl ?: SITE_URL,
        ]);
    }

    public function getGameDemo(string $gameIdHash, string $lang = 'bn', ?string $currency = null, ?string $homeUrl = null): array {
        return $this->request('getGameDemo', [
            'gameid' => $gameIdHash,
            'lang' => $lang,
            'currency' => $currency ?: $this->currency,
            'homeurl' => $homeUrl ?: SITE_URL,
        ]);
    }

    public function getPlayerHistory(string $username, int $limit = 50, int $offset = 0): array {
        return $this->request('getPlayerHistory', [
            'user_username' => $username,
            'limit' => $limit,
            'offset' => $offset,
        ]);
    }

    // Free Rounds methods (PDF Page 6: Returns not supported)
    public function addFreeRounds(): array {
        return ['error' => 1, 'message' => 'Free rounds not supported'];
    }

    public function getFreeRounds(): array {
        return ['error' => 1, 'message' => 'Free rounds not supported'];
    }

    public function deleteFreeRounds(): array {
        return ['error' => 1, 'message' => 'Free rounds not supported'];
    }
}

// Direct POST /api/softaggregator.php endpoint dispatcher
if (basename($_SERVER['SCRIPT_FILENAME'] ?? '') === 'softaggregator.php' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $method = trim($input['method'] ?? '');
    $client = new SoftAggregatorAPI(
        $input['api_login'] ?? null,
        $input['api_password'] ?? null
    );

    if (in_array($method, ['addFreeRounds', 'getFreeRounds', 'deleteFreeRounds'], true)) {
        jsonResponse(['error' => 1, 'message' => 'Free rounds not supported']);
    }

    if ($method) {
        $extra = $input;
        unset($extra['api_login'], $extra['api_password'], $extra['method']);
        jsonResponse($client->request($method, $extra));
    }
}
