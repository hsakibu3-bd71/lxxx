<?php
require_once __DIR__ . '/api/softaggregator_callback.php';
