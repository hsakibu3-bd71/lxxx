<?php
require_once __DIR__ . '/config.php';

// Check if install.php needs to run
if (!file_exists(__DIR__ . '/.installed') && getDB() === null) {
    header('Location: install.php');
    exit;
}

$user = getCurrentUser();
$settings = getSiteSettings();
$db = getDB();
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title>LivexWin - Bangladesh Premier Online Casino</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;600;700;800&family=Chakra+Petch:wght@700&display=swap" rel="stylesheet">
    <style>
        body, html { font-family: 'Hind Siliguri', sans-serif; touch-action: manipulation; -webkit-user-select: none; user-select: none; }
        .font-num { font-family: 'Chakra Petch', monospace; }
    </style>
</head>
<body class="bg-[#0e0102] text-white min-h-screen flex flex-col items-center justify-start select-none" oncontextmenu="return false;">
    <!-- Mobile Frame Container -->
    <div class="w-full max-w-md min-h-screen bg-[#140204] flex flex-col relative pb-20 shadow-2xl">
        
        <!-- Header with LivexWin Brand (No .com badge per user requirement) -->
        <header class="sticky top-0 z-40 bg-gradient-to-r from-[#240306] via-[#3d060c] to-[#240306] border-b border-[#5a0c13] px-3 py-2 flex items-center justify-between shadow-md">
            <!-- Brand Logo -->
            <div class="flex items-center gap-1.5 cursor-pointer" onclick="location.reload()">
                <div class="flex items-center font-black italic tracking-tighter text-2xl">
                    <span class="text-white drop-shadow-md">live</span>
                    <span class="text-amber-400 mx-0.5">X</span>
                    <span class="text-[#ff1a2d] drop-shadow-md">win</span>
                </div>
            </div>

            <!-- Header Right: User or Auth -->
            <div class="flex items-center gap-2">
                <?php if ($user): ?>
                    <div class="flex items-center gap-1.5 bg-black/60 px-2.5 py-1 rounded-full border border-yellow-500/40">
                        <span class="text-[10px] text-amber-300 font-bold">VIP <?= $user['vip_level'] ?></span>
                        <span class="text-xs font-black font-num text-yellow-300">৳ <?= number_format($user['balance'], 2) ?></span>
                    </div>
                    <button onclick="openModal('memberModal')" class="w-8 h-8 rounded-full bg-gradient-to-tr from-red-600 to-amber-500 text-white font-bold text-xs flex items-center justify-center border border-white/20">
                        👤
                    </button>
                <?php else: ?>
                    <button onclick="openAuth('login')" class="px-3 py-1 bg-[#250407] border border-yellow-400/80 text-yellow-300 text-xs font-bold rounded-full shadow cursor-pointer">
                        লগইন
                    </button>
                    <button onclick="openAuth('register')" class="px-3 py-1 bg-gradient-to-b from-amber-300 via-amber-400 to-orange-500 text-black text-xs font-extrabold rounded-full shadow cursor-pointer">
                        নিবন্ধন
                    </button>
                <?php endif; ?>
            </div>
        </header>

        <!-- Marquee Announcement -->
        <div class="bg-black/80 px-3 py-1.5 flex items-center gap-2 border-b border-red-950/60 text-xs text-amber-200">
            <span>📢</span>
            <marquee class="font-medium text-[11px]"><?= htmlspecialchars($settings['announcement_text'] ?? 'স্বাগতম LivexWin এ! প্রতিটি ডিপোজিটে পান তাৎক্ষণিক বোনাস।') ?></marquee>
        </div>

        <!-- Banner Slider Hero -->
        <div class="p-3">
            <div class="relative w-full h-44 rounded-2xl overflow-hidden shadow-xl border border-red-800/50 bg-gradient-to-r from-red-900 via-rose-950 to-red-900 flex flex-col justify-end p-4">
                <span class="bg-amber-400 text-black text-[10px] font-black px-2 py-0.5 rounded-full w-max mb-1">মেগা অফার ২০২৬</span>
                <h3 class="text-lg font-black text-white">প্রথম জমার উপর +১৮০% ক্যাশ বোনাস</h3>
                <p class="text-xs text-gray-200">বিকাশ ও নগদ দিয়ে ডিপোজিট করুন তাৎক্ষণিক</p>
                <div class="mt-2 flex gap-2">
                    <button onclick="openModal('depositModal')" class="px-3 py-1 bg-amber-400 text-black font-extrabold text-xs rounded-lg shadow">
                        জমা দিন
                    </button>
                    <button onclick="openModal('eggModal')" class="px-3 py-1 bg-black/60 border border-yellow-400 text-yellow-300 font-extrabold text-xs rounded-lg shadow">
                        সোনার ডিম ভাঙুন
                    </button>
                </div>
            </div>
        </div>

        <!-- Quick Bonus Event Buttons (Egg, Wheel, Red Packet, Rescue) -->
        <div class="grid grid-cols-4 gap-2 px-3 pb-2 text-center text-xs">
            <div onclick="openModal('eggModal')" class="bg-[#240306] p-2 rounded-xl border border-yellow-500/40 cursor-pointer active:scale-95 transition-transform">
                <span class="text-2xl block">🥚</span>
                <span class="font-bold text-[11px] text-yellow-300">গোল্ডেন এগ</span>
            </div>
            <div onclick="openModal('wheelModal')" class="bg-[#240306] p-2 rounded-xl border border-red-500/40 cursor-pointer active:scale-95 transition-transform">
                <span class="text-2xl block">🎡</span>
                <span class="font-bold text-[11px] text-rose-300">লাকি হুইল</span>
            </div>
            <div onclick="openModal('redPacketModal')" class="bg-[#240306] p-2 rounded-xl border border-rose-500/40 cursor-pointer active:scale-95 transition-transform">
                <span class="text-2xl block">🧧</span>
                <span class="font-bold text-[11px] text-red-300">রেড প্যাকেট</span>
            </div>
            <div onclick="openModal('rescueModal')" class="bg-[#240306] p-2 rounded-xl border border-emerald-500/40 cursor-pointer active:scale-95 transition-transform">
                <span class="text-2xl block">🛡️</span>
                <span class="font-bold text-[11px] text-emerald-300">উদ্ধার তহবিল</span>
            </div>
        </div>

        <!-- Games Grid Section -->
        <div class="p-3 space-y-3">
            <div class="flex justify-between items-center">
                <h3 class="text-sm font-black text-amber-300 flex items-center gap-1.5">
                    <span>🔥 জনপ্রিয় গেম ক্যাটালগ</span>
                </h3>
                <span class="text-[10px] text-gray-400">RTP ৯৭.২%</span>
            </div>

            <div class="grid grid-cols-2 gap-2.5">
                <!-- Game 1: Super Ace -->
                <div class="bg-[#220306] rounded-2xl overflow-hidden border border-[#520c13] shadow-md flex flex-col justify-between">
                    <img src="https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=400&q=80" class="w-full h-24 object-cover">
                    <div class="p-2.5">
                        <div class="flex justify-between items-center mb-1">
                            <span class="font-black text-xs text-white">Super Ace</span>
                            <span class="text-[9px] font-bold px-1.5 py-0.2 rounded bg-amber-400 text-black">JILI</span>
                        </div>
                        <button onclick="playDemoGame('Super Ace', 'JILI')" class="w-full py-1.5 bg-gradient-to-r from-red-600 to-rose-600 text-white font-bold text-xs rounded-lg shadow cursor-pointer">
                            খেলুন এখনই
                        </button>
                    </div>
                </div>

                <!-- Game 2: Fortune Gems -->
                <div class="bg-[#220306] rounded-2xl overflow-hidden border border-[#520c13] shadow-md flex flex-col justify-between">
                    <img src="https://images.unsplash.com/photo-1579783902614-a3fb3927b675?w=400&q=80" class="w-full h-24 object-cover">
                    <div class="p-2.5">
                        <div class="flex justify-between items-center mb-1">
                            <span class="font-black text-xs text-white">Fortune Gems</span>
                            <span class="text-[9px] font-bold px-1.5 py-0.2 rounded bg-amber-400 text-black">JILI</span>
                        </div>
                        <button onclick="playDemoGame('Fortune Gems', 'JILI')" class="w-full py-1.5 bg-gradient-to-r from-red-600 to-rose-600 text-white font-bold text-xs rounded-lg shadow cursor-pointer">
                            খেলুন এখনই
                        </button>
                    </div>
                </div>

                <!-- Game 3: FlyX Crash -->
                <div class="bg-[#220306] rounded-2xl overflow-hidden border border-[#520c13] shadow-md flex flex-col justify-between">
                    <img src="https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=400&q=80" class="w-full h-24 object-cover">
                    <div class="p-2.5">
                        <div class="flex justify-between items-center mb-1">
                            <span class="font-black text-xs text-white">FlyX Crash 100x</span>
                            <span class="text-[9px] font-bold px-1.5 py-0.2 rounded bg-blue-500 text-white">CRASH</span>
                        </div>
                        <button onclick="playDemoGame('FlyX Crash', 'Microgaming')" class="w-full py-1.5 bg-gradient-to-r from-red-600 to-rose-600 text-white font-bold text-xs rounded-lg shadow cursor-pointer">
                            খেলুন এখনই
                        </button>
                    </div>
                </div>

                <!-- Game 4: Happy Fishing -->
                <div class="bg-[#220306] rounded-2xl overflow-hidden border border-[#520c13] shadow-md flex flex-col justify-between">
                    <img src="https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=400&q=80" class="w-full h-24 object-cover">
                    <div class="p-2.5">
                        <div class="flex justify-between items-center mb-1">
                            <span class="font-black text-xs text-white">Happy Fishing</span>
                            <span class="text-[9px] font-bold px-1.5 py-0.2 rounded bg-cyan-500 text-white">ARCADE</span>
                        </div>
                        <button onclick="playDemoGame('Happy Fishing', 'JILI')" class="w-full py-1.5 bg-gradient-to-r from-red-600 to-rose-600 text-white font-bold text-xs rounded-lg shadow cursor-pointer">
                            খেলুন এখনই
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer Copyright strictly ©2026 livexwin.com -->
        <footer class="mt-auto px-4 py-6 text-center text-xs text-gray-500 border-t border-red-950/40">
            <p>©2026 livexwin.com সকল অধিকার সংরক্ষিত।</p>
            <p class="text-[10px] text-gray-600 mt-1">লাইসেন্সপ্রাপ্ত ও নিয়ন্ত্রিত অনলাইন বিনোদন গেমিং প্ল্যাটফর্ম</p>
        </footer>

        <!-- Bottom Navigation Bar (Authentic Home Icon - No Blue Live Badge) -->
        <nav class="fixed bottom-0 max-w-md w-full bg-[#1b0306] border-t border-[#4d0c13] py-2 px-3 flex justify-around items-center text-[10px] font-bold z-40 shadow-2xl">
            <a href="index.php" class="flex flex-col items-center text-yellow-400">
                <span class="text-base">🏠</span>
                <span>হোম</span>
            </a>
            <div onclick="openModal('depositModal')" class="flex flex-col items-center text-gray-400 hover:text-white cursor-pointer">
                <span class="text-base">💳</span>
                <span>ডিপোজিট</span>
            </div>
            <div onclick="openModal('withdrawModal')" class="flex flex-col items-center text-gray-400 hover:text-white cursor-pointer">
                <span class="text-base">💸</span>
                <span>উত্তোলন</span>
            </div>
            <div onclick="openModal('memberModal')" class="flex flex-col items-center text-gray-400 hover:text-white cursor-pointer">
                <span class="text-base">👤</span>
                <span>সদস্য কেন্দ্র</span>
            </div>
        </nav>
    </div>

    <!-- ---------------------------------------------------- -->
    <!-- MODALS: Golden Egg, Red Packet, Wheel, Member Center -->
    <!-- ---------------------------------------------------- -->

    <!-- GOLDEN EGG MODAL (Matching IMG_0284_e38acef0.png) -->
    <div id="eggModal" class="hidden fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-3">
        <div class="relative w-full max-w-sm rounded-3xl p-5 bg-radial from-amber-950 via-black to-black border-2 border-yellow-500/50 text-center shadow-2xl">
            <button onclick="closeModal('eggModal')" class="absolute top-3 right-3 text-gray-400 hover:text-white bg-black/60 p-1.5 rounded-full">✕</button>
            <span class="px-3 py-0.5 rounded-full bg-amber-500/20 text-yellow-300 text-[10px] font-bold border border-yellow-400/40">লাকি গোল্ডেন এগ</span>
            <h3 class="text-xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-amber-300 to-yellow-400 mt-1">
                যেকোনো ডিম ভেঙে পুরস্কার নিন
            </h3>
            <p class="text-xs text-gray-300 mt-0.5">
                সর্বোচ্চ <span class="text-yellow-300 font-bold font-num">৳ <?= number_format($settings['golden_egg_max_display'] ?? 99999) ?></span> ক্যাশ!
            </p>
            <div class="mt-1 text-[10px] text-amber-200 bg-black/50 py-1 px-2 rounded-full border border-amber-500/30 inline-block">
                VIP ১-৪: ৳<?= $settings['golden_egg_tier1'] ?? 9 ?> • VIP ৫-১০: ৳<?= $settings['golden_egg_tier2'] ?? 99 ?> • VIP ১১+: ৳<?= $settings['golden_egg_tier3'] ?? 199 ?>
            </div>

            <!-- 8 Eggs Grid matching IMG_0284 -->
            <div class="grid grid-cols-4 gap-2 my-4">
                <?php for ($i = 0; $i < 8; $i++): ?>
                    <div onclick="crackEgg(<?= $i ?>)" class="flex flex-col items-center cursor-pointer group active:scale-95">
                        <div class="w-12 h-16 rounded-[50%_50%_50%_50%/60%_60%_40%_40%] bg-gradient-to-tr from-amber-700 via-yellow-400 to-amber-200 border border-yellow-200 shadow-lg relative flex items-center justify-center">
                            <span id="eggText-<?= $i ?>" class="text-xs">✨</span>
                        </div>
                        <div class="w-14 h-2.5 bg-gradient-to-r from-red-900 to-rose-900 rounded-sm -mt-1 border-t border-yellow-400/80"></div>
                    </div>
                <?php endfor; ?>
            </div>

            <button onclick="crackEgg(0)" class="w-4/5 py-2.5 rounded-full font-black text-xs text-[#3b1202] bg-gradient-to-r from-[#ffe066] via-[#f59e0b] to-[#fbbf24] shadow-lg cursor-pointer">
                দাবি করুন
            </button>
        </div>
    </div>

    <!-- RED PACKET MODAL (Matching IMG_0275_8a9fb3f6.png) -->
    <div id="redPacketModal" class="hidden fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-3">
        <div class="relative w-full max-w-sm rounded-3xl p-5 bg-gradient-to-b from-[#3a0408] to-[#120103] border-2 border-red-500 text-center shadow-2xl">
            <button onclick="closeModal('redPacketModal')" class="absolute top-3 right-3 text-gray-400 hover:text-white bg-black/60 p-1.5 rounded-full">✕</button>
            <div class="text-3xl animate-pulse">👑</div>
            <div class="inline-block px-6 py-1 bg-red-600 text-white font-black text-xs rounded-md border border-yellow-300">
                পুরস্কার
            </div>
            <div class="text-[11px] text-amber-300 font-bold mt-1">00:00-03:00 ফ্রি ক্যাশ রেইন</div>

            <div onclick="claimRedPacket()" class="w-36 h-48 mx-auto my-3 rounded-2xl bg-gradient-to-b from-red-600 via-rose-600 to-red-800 border-2 border-yellow-400 flex flex-col items-center justify-center shadow-xl cursor-pointer active:scale-95 transition-transform">
                <div class="w-14 h-14 rounded-full bg-yellow-400 border-2 border-yellow-200 text-black flex items-center justify-center font-black text-xl shadow">
                    開
                </div>
                <span class="text-xs font-bold text-yellow-200 mt-2">ট্যাপ করে খুলুন</span>
            </div>

            <button onclick="claimRedPacket()" class="w-4/5 py-2.5 rounded-full font-black text-xs text-[#3b1202] bg-gradient-to-r from-yellow-300 to-amber-500 shadow-lg cursor-pointer">
                দাবি করুন
            </button>
        </div>
    </div>

    <!-- LUCKY WHEEL MODAL (Matching IMG_0276_46dc5975.png) -->
    <div id="wheelModal" class="hidden fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-3">
        <div class="relative w-full max-w-sm rounded-3xl p-5 bg-[#1b0306] border-2 border-yellow-500 text-center shadow-2xl">
            <button onclick="closeModal('wheelModal')" class="absolute top-3 right-3 text-gray-400 hover:text-white bg-black/60 p-1.5 rounded-full">✕</button>
            <h3 class="text-lg font-black text-yellow-300">লাকি স্পিন হুইল ইভেন্ট</h3>
            
            <!-- Countdown Timer Display e.g. ২৩ : ০৬ : ৩১ -->
            <div class="flex items-center justify-center gap-1.5 bg-black/60 px-4 py-1.5 rounded-full border border-yellow-500/50 my-2 text-xs">
                <span class="text-gray-300 font-bold">বাকি সময়:</span>
                <span class="text-yellow-300 font-black font-num"><?= htmlspecialchars($settings['wheel_countdown_timer'] ?? '২৩ : ০৬ : ৩১') ?></span>
            </div>

            <div class="w-full bg-amber-400/20 p-2 rounded-xl border border-yellow-400/40 text-[11px] mb-3">
                <span class="text-yellow-300 font-bold">গ্র্যান্ড প্রাইজ:</span>
                <span class="font-black text-white">iPhone 18 Pro Max</span>
            </div>

            <button onclick="spinWheel()" class="w-4/5 py-3 rounded-full font-black text-xs text-[#3b1202] bg-gradient-to-r from-amber-400 to-yellow-300 shadow-xl cursor-pointer active:scale-95">
                স্পিন করুন (GO)
            </button>
        </div>
    </div>

    <!-- RESCUE FUND MODAL (উদ্ধার তহবিল) -->
    <div id="rescueModal" class="hidden fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-3">
        <div class="relative w-full max-w-sm rounded-3xl p-5 bg-[#0f172a] border-2 border-emerald-500 text-center shadow-2xl">
            <button onclick="closeModal('rescueModal')" class="absolute top-3 right-3 text-gray-400 hover:text-white bg-black/60 p-1.5 rounded-full">✕</button>
            <div class="text-3xl text-emerald-400 mb-1">🛡️</div>
            <h3 class="text-lg font-black text-emerald-300">দৈনিক উদ্ধার তহবিল</h3>
            <p class="text-xs text-gray-300 mt-1">ক্ষতিপূরণ বাবদ <?= $settings['rescue_fund_percentage'] ?? 10 ?>% ক্যাশব্যাক সহায়তা</p>

            <button onclick="claimRescue()" class="w-full mt-4 py-3 bg-gradient-to-r from-emerald-500 to-teal-600 font-black text-xs text-white rounded-xl shadow cursor-pointer">
                উদ্ধার তহবিল গ্রহণ করুন
            </button>
        </div>
    </div>

    <!-- MEMBER CENTER / BETTING HISTORY / MY CARDS (5 max, locked, masked) -->
    <div id="memberModal" class="hidden fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-3">
        <div class="relative w-full max-w-md max-h-[90vh] overflow-y-auto rounded-3xl p-5 bg-[#1b0306] border-2 border-red-700 text-left shadow-2xl">
            <button onclick="closeModal('memberModal')" class="absolute top-3 right-3 text-gray-400 hover:text-white bg-black/60 p-1.5 rounded-full">✕</button>
            
            <h3 class="text-lg font-black text-white mb-2">সদস্য কেন্দ্র (Member Center)</h3>
            
            <?php if ($user): ?>
                <div class="p-3 bg-black/60 rounded-2xl border border-white/10 mb-4 flex justify-between items-center text-xs">
                    <div>
                        <span class="font-bold text-white block"><?= htmlspecialchars($user['username']) ?></span>
                        <span class="text-amber-400 font-bold">VIP <?= $user['vip_level'] ?></span>
                    </div>
                    <span class="font-black text-sm text-yellow-300 font-num">৳ <?= number_format($user['balance'], 2) ?></span>
                </div>

                <!-- 1. Betting History (Filterable by All, Win, Loss) -->
                <div class="mb-4 space-y-2">
                    <h4 class="text-xs font-bold text-amber-300">📊 বাজির ইতিহাস (Betting History)</h4>
                    <div id="betList" class="max-h-40 overflow-y-auto space-y-1.5 text-xs">
                        <p class="text-gray-400 text-[11px]">লোড হচ্ছে...</p>
                    </div>
                </div>

                <!-- 2. My Cards (Max 5, Locked, Masked e.g. 017*****485) -->
                <div class="mb-4 space-y-2">
                    <div class="flex justify-between items-center">
                        <h4 class="text-xs font-bold text-amber-300">💳 আমার কার্ড (সর্বোচ্চ ৫টি, স্থায়ী লকড)</h4>
                    </div>
                    <div id="cardsList" class="space-y-1.5 text-xs">
                        <!-- Loaded dynamically -->
                    </div>
                </div>

                <!-- 3. Logout Button inside Member Center -->
                <button onclick="logoutUser()" class="w-full py-2.5 mt-2 bg-gradient-to-r from-red-700 to-rose-700 hover:from-red-600 hover:to-rose-600 text-white font-black text-xs rounded-xl shadow cursor-pointer">
                    অ্যাকাউন্ট থেকে লগআউট করুন (Logout)
                </button>
            <?php else: ?>
                <p class="text-xs text-gray-300 py-6 text-center">দয়া করে প্রথমে লগইন করুন।</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- AUTH MODAL (LOGIN & REGISTRATION) -->
    <div id="authModal" class="hidden fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-3">
        <div class="relative w-full max-w-sm rounded-3xl p-5 bg-[#1b0306] border-2 border-red-700 text-left shadow-2xl text-xs space-y-3">
            <button onclick="closeModal('authModal')" class="absolute top-3 right-3 text-gray-400 hover:text-white bg-black/60 p-1.5 rounded-full">✕</button>
            <div class="grid grid-cols-2 gap-2 bg-black/50 p-1 rounded-xl border border-red-900/50">
                <button id="tabLoginBtn" onclick="switchAuthTab('login')" class="py-2 rounded-lg font-black text-xs bg-red-600 text-white cursor-pointer">লগইন (Login)</button>
                <button id="tabRegBtn" onclick="switchAuthTab('register')" class="py-2 rounded-lg font-black text-xs text-gray-400 cursor-pointer">নিবন্ধন (Register)</button>
            </div>
            <div id="authMsg" class="hidden p-2 rounded-xl text-center font-bold"></div>
            <div>
                <label class="block text-gray-300 font-bold mb-1">ইউজারনেম (Username):</label>
                <input type="text" id="authUsername" placeholder="ইউজারনেম লিখুন" class="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-white font-bold">
            </div>
            <div id="authPhoneWrap" class="hidden">
                <label class="block text-gray-300 font-bold mb-1">মোবাইল নম্বর (১১ সংখ্যা):</label>
                <input type="tel" id="authPhone" placeholder="017XXXXXXXX" maxlength="11" class="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-white font-mono font-bold">
            </div>
            <div>
                <label class="block text-gray-300 font-bold mb-1">পাসওয়ার্ড (Password):</label>
                <input type="password" id="authPassword" placeholder="পাসওয়ার্ড দিন" class="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-white font-bold">
            </div>
            <button id="authSubmitBtn" onclick="submitAuth()" class="w-full py-3 bg-gradient-to-r from-amber-400 to-yellow-500 font-black text-black rounded-xl shadow cursor-pointer">
                লগইন নিশ্চিত করুন
            </button>
        </div>
    </div>

    <!-- DEPOSIT MODAL -->
    <div id="depositModal" class="hidden fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-3">
        <div class="relative w-full max-w-sm rounded-3xl p-5 bg-[#1b0306] border-2 border-red-700 text-left shadow-2xl text-xs space-y-3">
            <button onclick="closeModal('depositModal')" class="absolute top-3 right-3 text-gray-400 hover:text-white bg-black/60 p-1.5 rounded-full">✕</button>
            <h3 class="text-base font-black text-white">টাকা জমা দিন (Deposit)</h3>
            <div>
                <label class="block text-gray-300 font-bold mb-1">পেমেন্ট মেথড:</label>
                <select id="depMethod" class="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-white font-bold">
                    <option value="nagad">Nagad (নগদ)</option>
                    <option value="bkash">bKash (বিকাশ)</option>
                    <option value="rocket">Rocket (রকেট)</option>
                </select>
            </div>
            <div>
                <label class="block text-gray-300 font-bold mb-1">ডিপোজিট পরিমাণ (৳):</label>
                <input type="number" id="depAmount" value="500" class="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-white font-mono font-bold">
            </div>
            <div>
                <label class="block text-gray-300 font-bold mb-1">প্রেরকের নম্বর:</label>
                <input type="tel" id="depPhone" placeholder="017XXXXXXXX" class="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-white font-mono font-bold">
            </div>
            <div>
                <label class="block text-gray-300 font-bold mb-1">ট্রানজেকশন আইডি (TrxID):</label>
                <input type="text" id="depTrxId" placeholder="8N7A6D5F4G" class="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-white font-mono font-bold uppercase">
            </div>
            <button onclick="submitDeposit()" class="w-full py-3 bg-gradient-to-r from-amber-400 to-yellow-500 font-black text-black rounded-xl shadow cursor-pointer">
                ডিপোজিট নিশ্চিত করুন
            </button>
        </div>
    </div>

    <!-- WITHDRAW MODAL WITH 6-DIGIT PIN -->
    <div id="withdrawModal" class="hidden fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-3">
        <div class="relative w-full max-w-sm rounded-3xl p-5 bg-[#1b0306] border-2 border-red-700 text-left shadow-2xl text-xs space-y-3">
            <button onclick="closeModal('withdrawModal')" class="absolute top-3 right-3 text-gray-400 hover:text-white bg-black/60 p-1.5 rounded-full">✕</button>
            <h3 class="text-base font-black text-white">টাকা উত্তোলন (Withdraw)</h3>
            <div>
                <label class="block text-gray-300 font-bold mb-1">উত্তোলনের পরিমাণ (৳):</label>
                <input type="number" id="wdAmount" value="500" class="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-white font-mono font-bold">
            </div>
            <div>
                <label class="block text-gray-300 font-bold mb-1">মোবাইল ওয়ালেট নম্বর (আমার কার্ড):</label>
                <input type="text" id="wdAccount" placeholder="01712062485" class="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-white font-mono font-bold">
            </div>
            <div>
                <label class="block text-gray-300 font-bold mb-1">৬ সংখ্যার গোপন উত্তোলন পিন/পাসওয়ার্ড:</label>
                <input type="password" id="wdPin" maxlength="6" placeholder="******" class="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-center tracking-widest text-white font-mono font-bold">
            </div>
            <button onclick="submitWithdrawal()" class="w-full py-3 bg-gradient-to-r from-red-600 to-rose-600 font-black text-white rounded-xl shadow cursor-pointer">
                উত্তোলন নিশ্চিত করুন
            </button>
        </div>
    </div>

    <!-- JavaScript Interactions -->
    <script>
        let currentAuthMode = 'login';
        function openAuth(mode) {
            switchAuthTab(mode || 'login');
            openModal('authModal');
        }
        function switchAuthTab(mode) {
            currentAuthMode = mode;
            const loginBtn = document.getElementById('tabLoginBtn');
            const regBtn = document.getElementById('tabRegBtn');
            const phoneWrap = document.getElementById('authPhoneWrap');
            const submitBtn = document.getElementById('authSubmitBtn');
            if (mode === 'register') {
                regBtn.className = 'py-2 rounded-lg font-black text-xs bg-red-600 text-white cursor-pointer';
                loginBtn.className = 'py-2 rounded-lg font-black text-xs text-gray-400 cursor-pointer';
                phoneWrap.classList.remove('hidden');
                submitBtn.innerText = 'নিবন্ধন সম্পন্ন করুন (+৳৬০ বোনাস)';
            } else {
                loginBtn.className = 'py-2 rounded-lg font-black text-xs bg-red-600 text-white cursor-pointer';
                regBtn.className = 'py-2 rounded-lg font-black text-xs text-gray-400 cursor-pointer';
                phoneWrap.classList.add('hidden');
                submitBtn.innerText = 'লগইন নিশ্চিত করুন';
            }
        }
        async function submitAuth() {
            const username = document.getElementById('authUsername').value;
            const password = document.getElementById('authPassword').value;
            const phone = document.getElementById('authPhone').value;
            const res = await fetch('api/auth.php?action=' + currentAuthMode, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password, phone })
            }).then(r => r.json());
            const msgBox = document.getElementById('authMsg');
            msgBox.classList.remove('hidden');
            msgBox.className = 'p-2 rounded-xl text-center font-bold ' + (res.success ? 'bg-emerald-900/80 text-emerald-200' : 'bg-red-900/80 text-red-200');
            msgBox.innerText = res.message;
            if (res.success) setTimeout(() => location.reload(), 600);
        }
        async function logoutUser() {
            await fetch('api/auth.php?action=logout', { credentials: 'same-origin' });
            location.reload();
        }
        async function submitDeposit() {
            const amount = document.getElementById('depAmount').value;
            const method = document.getElementById('depMethod').value;
            const senderPhone = document.getElementById('depPhone').value;
            const trxId = document.getElementById('depTrxId').value;
            const res = await fetch('api/wallet.php?action=deposit', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ amount, method, senderPhone, trxId })
            }).then(r => r.json());
            alert(res.message);
            if (res.success) location.reload();
        }
        function openModal(id) {
            document.getElementById(id).classList.remove('hidden');
            if (id === 'memberModal') loadMemberData();
        }
        function closeModal(id) {
            document.getElementById(id).classList.add('hidden');
        }

        async function crackEgg(idx) {
            const res = await fetch('api/bonus.php?action=golden_egg', { credentials: 'same-origin' }).then(r => r.json());
            alert(res.message);
            if (res.success) location.reload();
        }

        async function claimRedPacket() {
            const res = await fetch('api/bonus.php?action=red_packet', { credentials: 'same-origin' }).then(r => r.json());
            alert(res.message);
            if (res.success) location.reload();
        }

        async function spinWheel() {
            const res = await fetch('api/bonus.php?action=wheel', { credentials: 'same-origin' }).then(r => r.json());
            alert(res.message);
            if (res.success) location.reload();
        }

        async function claimRescue() {
            const res = await fetch('api/bonus.php?action=rescue_fund', { credentials: 'same-origin' }).then(r => r.json());
            alert(res.message);
            if (res.success) location.reload();
        }

        async function submitWithdrawal() {
            const amt = document.getElementById('wdAmount').value;
            const acc = document.getElementById('wdAccount').value;
            const pin = document.getElementById('wdPin').value;

            const res = await fetch('api/wallet.php?action=withdraw', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ amount: amt, accountNumber: acc, trxPass: pin })
            }).then(r => r.json());

            alert(res.message);
            if (res.success) location.reload();
        }

        async function loadMemberData() {
            // Load betting history
            const bRes = await fetch('api/betting_history.php?action=list').then(r => r.json());
            const bBox = document.getElementById('betList');
            if (bRes.success && bRes.bets && bRes.bets.length > 0) {
                bBox.innerHTML = bRes.bets.map(b => `
                    <div class="p-2 bg-black/50 border border-white/5 rounded-lg flex justify-between items-center">
                        <div>
                            <strong class="text-white block">${b.game_name} (${b.provider})</strong>
                            <span class="text-[10px] text-gray-400 font-mono">${b.created_at}</span>
                        </div>
                        <span class="font-bold ${b.profit > 0 ? 'text-emerald-400' : 'text-red-400'}">
                            ${b.profit > 0 ? '+' : ''}৳${Number(b.profit).toFixed(2)}
                        </span>
                    </div>
                `).join('');
            } else {
                bBox.innerHTML = '<p class="text-gray-500 text-[11px]">কোনো বাজির রেকর্ড নেই।</p>';
            }

            // Load cards
            const cRes = await fetch('api/cards.php?action=list').then(r => r.json());
            const cBox = document.getElementById('cardsList');
            if (cRes.success && cRes.cards && cRes.cards.length > 0) {
                cBox.innerHTML = cRes.cards.map(c => `
                    <div class="p-2 bg-black/50 border border-white/5 rounded-lg flex justify-between items-center">
                        <div>
                            <span class="uppercase text-[9px] px-1 bg-amber-400 text-black font-bold rounded">${c.type}</span>
                            <span class="text-white font-mono font-bold ml-1">${c.masked_number}</span>
                        </div>
                        <span class="text-[9px] px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">লকড (🔒)</span>
                    </div>
                `).join('');
            } else {
                cBox.innerHTML = '<p class="text-gray-500 text-[11px]">কোনো কার্ড সংরক্ষিত নেই।</p>';
            }
        }

        // --- Casino Game Fullscreen Iframe Modal (with Live Handshake) ---
        function playDemoGame(name, prov) {
            document.getElementById('gameFrameTitle').innerText = name;
            document.getElementById('gameFrameProvider').innerText = prov;
            const url = 'game_frame.php?name=' + encodeURIComponent(name) + '&provider=' + encodeURIComponent(prov) + '&user=<?= urlencode($user["username"] ?? "Player") ?>&balance=<?= $user["balance"] ?? 500 ?>';
            document.getElementById('casinoIframe').src = url;
            document.getElementById('gameIframeModal').classList.remove('hidden');
        }

        function closeGameIframe() {
            document.getElementById('casinoIframe').src = 'about:blank';
            document.getElementById('gameIframeModal').classList.add('hidden');
            location.reload();
        }

        function reloadGameIframe() {
            const cur = document.getElementById('casinoIframe').src;
            document.getElementById('casinoIframe').src = cur;
        }

        // --- Anti-Inspection & Anti-Tamper & Anti-Zoom Security Guards ---
        document.addEventListener('contextmenu', function(e) {
            e.preventDefault();
            return false;
        });

        document.addEventListener('keydown', function(e) {
            if (e.key === 'F12' || (e.ctrlKey && (e.key === 'u' || e.key === 's' || e.key === 'p' || e.shiftKey))) {
                e.preventDefault();
                return false;
            }
        });

        document.addEventListener('gesturestart', function(e) { e.preventDefault(); });
        document.addEventListener('touchmove', function(e) {
            if (e.touches.length > 1) {
                e.preventDefault();
            }
        }, { passive: false });
    </script>

    <!-- Casino Game Responsive Fullscreen Iframe Modal -->
    <div id="gameIframeModal" class="fixed inset-0 z-50 bg-black flex flex-col hidden select-none" oncontextmenu="return false;">
        <div class="h-12 bg-gradient-to-r from-[#1f0205] via-[#33050a] to-[#1f0205] border-b border-[#5a0c13] px-3 flex items-center justify-between text-white shadow-xl z-20">
            <div class="flex items-center gap-2">
                <button onclick="closeGameIframe()" class="p-1.5 rounded-lg bg-black/40 hover:bg-black/60 text-gray-300 hover:text-white border border-white/10 text-xs font-bold cursor-pointer">
                    ← সাইটে ফিরুন
                </button>
                <div class="flex flex-col">
                    <span id="gameFrameTitle" class="text-xs font-bold text-white truncate max-w-[130px]">Game</span>
                    <span id="gameFrameProvider" class="text-[9px] font-bold text-yellow-400 uppercase tracking-wider">PROVIDER</span>
                </div>
            </div>
            <div class="flex items-center gap-2">
                <div class="flex items-center gap-1.5 bg-black/50 border border-yellow-500/30 px-2.5 py-1 rounded-full text-xs font-mono font-black text-yellow-300">
                    ৳ <span id="gameFrameBalance"><?= number_format($user['balance'] ?? 500, 2) ?></span>
                </div>
                <button onclick="reloadGameIframe()" class="p-1.5 rounded-lg bg-black/40 text-gray-300 border border-white/10 text-xs cursor-pointer" title="রিলোড">🔄</button>
            </div>
        </div>
        <div class="flex-1 w-full h-[calc(100%-48px)] relative bg-[#0a0002]">
            <iframe id="casinoIframe" src="about:blank" class="w-full h-full border-0 select-none" allow="fullscreen; autoplay; screen-wake-lock; orientation"></iframe>
        </div>
    </div>
</body>
</html>
