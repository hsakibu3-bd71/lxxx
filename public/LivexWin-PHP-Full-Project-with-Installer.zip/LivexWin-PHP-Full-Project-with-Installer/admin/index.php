<?php
require_once __DIR__ . '/../config.php';

$user = getCurrentUser();
// Admin gate
if (!$user || ($user['role'] !== 'admin' && $user['role'] !== 'superadmin')) {
    // If not logged in as admin, show login or redirect
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admin_login'])) {
        $u = trim($_POST['username'] ?? '');
        $p = trim($_POST['password'] ?? '');
        $db = getDB();
        $stmt = $db->prepare("SELECT id, password_hash, role FROM users WHERE username = ? AND role IN ('admin','superadmin') LIMIT 1");
        $stmt->execute([$u]);
        $row = $stmt->fetch();
        if ($row && password_verify($p, $row['password_hash'])) {
            $_SESSION['user_id'] = $row['id'];
            header('Location: index.php');
            exit;
        } else {
            $loginErr = 'ভুল অ্যাডমিন ইউজারনেম বা পাসওয়ার্ড!';
        }
    }
    ?>
    <!DOCTYPE html>
    <html lang="bn">
    <head>
        <meta charset="UTF-8">
        <title>LivexWin - অ্যাডমিন লগইন</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;600;700&display=swap" rel="stylesheet">
        <style>body { font-family: 'Hind Siliguri', sans-serif; }</style>
    </head>
    <body class="bg-[#0f0203] text-white min-h-screen flex items-center justify-center p-4">
        <div class="max-w-sm w-full bg-[#1e0407] border border-red-700/60 rounded-3xl p-6 shadow-2xl">
            <h2 class="text-xl font-black text-center text-yellow-300 mb-2">LivexWin Master Admin</h2>
            <p class="text-xs text-center text-gray-400 mb-4">লগইন করে অ্যাডমিন প্যানেলে প্রবেশ করুন</p>
            <?php if (!empty($loginErr)): ?>
                <div class="p-2.5 mb-3 bg-red-900/60 text-red-200 text-xs rounded-xl font-bold"><?= htmlspecialchars($loginErr) ?></div>
            <?php endif; ?>
            <form method="POST" class="space-y-3 text-xs">
                <input type="hidden" name="admin_login" value="1">
                <div>
                    <label class="block text-gray-300 font-bold mb-1">অ্যাডমিন ইউজারনেম:</label>
                    <input type="text" name="username" value="admin" required class="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-white font-bold">
                </div>
                <div>
                    <label class="block text-gray-300 font-bold mb-1">পাসওয়ার্ড:</label>
                    <input type="password" name="password" required class="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-white font-bold">
                </div>
                <button type="submit" class="w-full py-2.5 bg-gradient-to-r from-red-600 to-rose-600 font-black text-white rounded-xl shadow-lg mt-2 cursor-pointer">
                    অ্যাডমিন প্যানেলে প্রবেশ করুন
                </button>
            </form>
        </div>
    </body>
    </html>
    <?php
    exit;
}

$db = getDB();
$tab = $_GET['tab'] ?? 'overview';
$msg = '';

// Handle Actions (Approve/Reject Withdrawals, Update Settings)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['approve_tx'])) {
        $txId = $_POST['tx_id'];
        $db->prepare("UPDATE transactions SET status = 'approved' WHERE id = ?")->execute([$txId]);
        $msg = "ট্রানজেকশন $txId সফলভাবে অনুমোদিত হয়েছে!";
    }
    if (isset($_POST['reject_tx'])) {
        $txId = $_POST['tx_id'];
        // Refund back to player
        $stmt = $db->prepare("SELECT user_id, amount FROM transactions WHERE id = ? LIMIT 1");
        $stmt->execute([$txId]);
        $tx = $stmt->fetch();
        if ($tx) {
            $db->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$tx['amount'], $tx['user_id']]);
            $db->prepare("UPDATE transactions SET status = 'rejected' WHERE id = ?")->execute([$txId]);
            $msg = "ট্রানজেকশন $txId বাতিল ও টাকা প্লেয়ারের ওয়ালেটে রিফান্ড করা হয়েছে!";
        }
    }
    if (isset($_POST['save_promotions'])) {
        $eggMax = (int)$_POST['golden_egg_max_display'];
        $egg1 = (int)$_POST['golden_egg_tier1'];
        $egg2 = (int)$_POST['golden_egg_tier2'];
        $egg3 = (int)$_POST['golden_egg_tier3'];
        $timer = trim($_POST['wheel_countdown_timer']);
        $wheel1 = (int)$_POST['wheel_tier1'];
        $wheel2 = (int)$_POST['wheel_tier2'];
        $wheel3 = (int)$_POST['wheel_tier3'];
        $redLimit = (int)$_POST['red_packet_daily_limit'];
        $rescuePct = (float)$_POST['rescue_fund_percentage'];
        $rescueMax = (float)$_POST['rescue_fund_daily_max'];

        $stmt = $db->prepare("UPDATE site_settings SET golden_egg_max_display = ?, golden_egg_tier1 = ?, golden_egg_tier2 = ?, golden_egg_tier3 = ?, wheel_countdown_timer = ?, wheel_tier1 = ?, wheel_tier2 = ?, wheel_tier3 = ?, red_packet_daily_limit = ?, rescue_fund_percentage = ?, rescue_fund_daily_max = ? WHERE id = 1");
        $stmt->execute([$eggMax, $egg1, $egg2, $egg3, $timer, $wheel1, $wheel2, $wheel3, $redLimit, $rescuePct, $rescueMax]);
        $msg = "প্রমোশন ও বোনাস সেটিংস সফলভাবে সংরক্ষিত হয়েছে!";
    }
    if (isset($_POST['save_softaggregator'])) {
        $login = trim($_POST['softaggregator_api_login'] ?? '');
        $pwd = trim($_POST['softaggregator_api_password'] ?? '');
        $salt = trim($_POST['softaggregator_salt_key'] ?? '');
        $curr = trim($_POST['softaggregator_currency'] ?? 'BDT');
        $cntry = trim($_POST['softaggregator_country'] ?? 'BD');
        $db->prepare("UPDATE site_settings SET softaggregator_api_login = ?, softaggregator_api_password = ?, softaggregator_salt_key = ?, softaggregator_currency = ?, softaggregator_country = ? WHERE id = 1")
           ->execute([$login, $pwd, $salt, $curr, $cntry]);
        $msg = "SoftAggregator API ও ওয়ালেট কলব্যাক সেটিংস সফলভাবে সংরক্ষিত হয়েছে!";
    }

    // Media & Branding Image (URL + File Upload)
    if (isset($_POST['save_media_branding'])) {
        $logoUrl = trim($_POST['site_logo_url'] ?? '');
        $uploadedLogo = saveUploadedImage('site_logo_file');
        if ($uploadedLogo) $logoUrl = $uploadedLogo;

        $favUrl = trim($_POST['site_favicon_url'] ?? '');
        $uploadedFav = saveUploadedImage('site_favicon_file');
        if ($uploadedFav) $favUrl = $uploadedFav;

        $eggImg = trim($_POST['golden_egg_img'] ?? '');
        $uploadedEgg = saveUploadedImage('golden_egg_file');
        if ($uploadedEgg) $eggImg = $uploadedEgg;

        $redImg = trim($_POST['red_packet_img'] ?? '');
        $uploadedRed = saveUploadedImage('red_packet_file');
        if ($uploadedRed) $redImg = $uploadedRed;

        $wheelImg = trim($_POST['wheel_img'] ?? '');
        $uploadedWheel = saveUploadedImage('wheel_file');
        if ($uploadedWheel) $wheelImg = $uploadedWheel;

        $rescueImg = trim($_POST['rescue_fund_img'] ?? '');
        $uploadedRescue = saveUploadedImage('rescue_fund_file');
        if ($uploadedRescue) $rescueImg = $uploadedRescue;

        $db->prepare("UPDATE site_settings SET site_logo_url = ?, site_favicon_url = ?, golden_egg_img = ?, red_packet_img = ?, wheel_img = ?, rescue_fund_img = ? WHERE id = 1")
           ->execute([$logoUrl, $favUrl, $eggImg, $redImg, $wheelImg, $rescueImg]);
        $msg = "ব্র্যান্ডিং ও প্রমোশন ছবি সফলভাবে সংরক্ষিত হয়েছে!";
    }

    // Add Banner (URL + File Upload)
    if (isset($_POST['add_banner'])) {
        $badge = trim($_POST['banner_badge'] ?? 'নতুন বোনাস');
        $title1 = trim($_POST['banner_title1'] ?? '');
        $title2 = trim($_POST['banner_title2'] ?? '');
        $amount = trim($_POST['banner_amount'] ?? '');
        $btnText = trim($_POST['banner_btn_text'] ?? 'এখনই নিন');
        $action = trim($_POST['banner_action'] ?? 'deposit');
        $imgUrl = trim($_POST['banner_img_url'] ?? '');
        $uploadedBanner = saveUploadedImage('banner_file');
        if ($uploadedBanner) $imgUrl = $uploadedBanner;

        if ($imgUrl) {
            $db->prepare("INSERT INTO banners (badge, title1, title2, amount, button_text, action, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)")
               ->execute([$badge, $title1, $title2, $amount, $btnText, $action, $imgUrl]);
            $msg = "নতুন ব্যানার সফলভাবে তৈরি হয়েছে!";
        }
    }

    if (isset($_POST['delete_banner'])) {
        $bId = (int)$_POST['banner_id'];
        $db->prepare("DELETE FROM banners WHERE id = ?")->execute([$bId]);
        $msg = "ব্যানার সফলভাবে মুছে ফেলা হয়েছে!";
    }

    // Update Game Thumbnail (URL + File Upload)
    if (isset($_POST['save_game_thumb'])) {
        $gId = trim($_POST['game_id'] ?? '');
        $gName = trim($_POST['game_name'] ?? '');
        $gProv = trim($_POST['game_provider'] ?? '');
        $gImg = trim($_POST['game_img_url'] ?? '');
        $uploadedGame = saveUploadedImage('game_file');
        if ($uploadedGame) $gImg = $uploadedGame;
        $gRtp = (float)($_POST['game_rtp'] ?? 97.2);

        $stmt = $db->prepare("INSERT INTO games_meta (id, name, provider, image_url, rtp) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE name=VALUES(name), provider=VALUES(provider), image_url=VALUES(image_url), rtp=VALUES(rtp)");
        $stmt->execute([$gId, $gName, $gProv, $gImg, $gRtp]);
        $msg = "গেমের ছবি ও তথ্য সংরক্ষিত হয়েছে!";
    }
}

$settings = getSiteSettings();
$totalUsers = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
$pendingWithdrawals = $db->query("SELECT * FROM transactions WHERE type = 'withdraw' AND status = 'pending' ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LivexWin Master Control Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>body { font-family: 'Hind Siliguri', sans-serif; }</style>
</head>
<body class="bg-[#0d0203] text-gray-100 min-h-screen flex flex-col font-sans">
    <!-- Admin Header -->
    <header class="bg-[#240407] border-b border-[#5a0c13] px-6 py-3 flex justify-between items-center shadow-lg">
        <div class="flex items-center gap-3">
            <span class="text-xl font-black text-yellow-400">LivexWin Admin</span>
            <span class="bg-red-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">PHP & MySQL Master</span>
        </div>
        <div class="flex items-center gap-3 text-xs">
            <span class="text-gray-300">অ্যাডমিন: <strong class="text-white"><?= htmlspecialchars($user['username']) ?></strong></span>
            <a href="../index.php" class="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 text-white rounded-lg">সাইটে যান</a>
            <a href="../api/auth.php?action=logout" class="px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-lg">লগআউট</a>
        </div>
    </header>

    <!-- Nav Tabs -->
    <nav class="bg-[#1b0306] border-b border-[#4d0c13] px-6 flex gap-2 overflow-x-auto text-xs font-bold">
        <a href="?tab=overview" class="py-3 px-3 border-b-2 <?= $tab === 'overview' ? 'border-yellow-400 text-yellow-300' : 'border-transparent text-gray-400' ?>">ওভারভিউ (Overview)</a>
        <a href="?tab=promotions" class="py-3 px-3 border-b-2 <?= $tab === 'promotions' ? 'border-yellow-400 text-yellow-300' : 'border-transparent text-gray-400' ?>">🎁 প্রমোশন ও বোনাস কন্ট্রোল</a>
        <a href="?tab=media" class="py-3 px-3 border-b-2 <?= $tab === 'media' ? 'border-yellow-400 text-yellow-300' : 'border-transparent text-gray-400' ?>">🎨 ছবি ও ব্যানার (লিংক ও আপলোড)</a>
        <a href="?tab=softaggregator" class="py-3 px-3 border-b-2 <?= $tab === 'softaggregator' ? 'border-yellow-400 text-yellow-300' : 'border-transparent text-gray-400' ?>">🎰 SoftAggregator ও Wallet Callback URL</a>
        <a href="?tab=withdrawals" class="py-3 px-3 border-b-2 <?= $tab === 'withdrawals' ? 'border-yellow-400 text-yellow-300' : 'border-transparent text-gray-400' ?>">উত্তোলন অনুমোদন (<?= count($pendingWithdrawals) ?>)</a>
        <a href="?tab=users" class="py-3 px-3 border-b-2 <?= $tab === 'users' ? 'border-yellow-400 text-yellow-300' : 'border-transparent text-gray-400' ?>">প্লেয়ার তালিকা (<?= $totalUsers ?>)</a>
    </nav>

    <main class="flex-1 p-6 max-w-6xl mx-auto w-full">
        <?php if ($msg): ?>
            <div class="p-3 mb-4 bg-emerald-900/80 border border-emerald-500 text-emerald-200 text-xs rounded-xl font-bold">
                <?= htmlspecialchars($msg) ?>
            </div>
        <?php endif; ?>

        <!-- TAB: PROMOTIONS CONTROL (Requested by User) -->
        <?php if ($tab === 'promotions'): ?>
            <form method="POST" class="space-y-6 bg-[#1a0305] p-6 rounded-3xl border border-red-900/60 shadow-xl">
                <input type="hidden" name="save_promotions" value="1">
                <div class="flex justify-between items-center border-b border-white/10 pb-3">
                    <div>
                        <h2 class="text-lg font-black text-yellow-300">🎁 বোনাস ও প্রমোশন কন্ট্রোল প্যানেল</h2>
                        <p class="text-xs text-gray-400">গোল্ডেন এগ, লাকি স্পিন হুইল, রেড প্যাকেট ও উদ্ধার তহবিলের মান নিয়ন্ত্রণ করুন</p>
                    </div>
                    <button type="submit" class="px-5 py-2.5 bg-gradient-to-r from-amber-400 to-yellow-400 text-black font-black text-xs rounded-xl shadow-lg hover:brightness-110 cursor-pointer">
                        সকল পরিবর্তন সংরক্ষণ করুন ✓
                    </button>
                </div>

                <!-- 1. Golden Egg Control -->
                <div class="bg-black/40 p-4 rounded-2xl border border-yellow-500/30 space-y-3">
                    <h3 class="text-sm font-bold text-yellow-400 flex items-center gap-1.5">
                        <span>🥚 ১. গোল্ডেন এগ সেটিংস (Golden Egg)</span>
                    </h3>
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                        <div>
                            <label class="block text-gray-300 font-bold mb-1">সর্বোচ্চ প্রদর্শিত প্রাইজ:</label>
                            <input type="number" name="golden_egg_max_display" value="<?= $settings['golden_egg_max_display'] ?? 99999 ?>" class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white font-mono font-bold">
                        </div>
                        <div>
                            <label class="block text-gray-300 font-bold mb-1">VIP ১-৪ পুরস্কার:</label>
                            <input type="number" name="golden_egg_tier1" value="<?= $settings['golden_egg_tier1'] ?? 9 ?>" class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white font-mono font-bold">
                        </div>
                        <div>
                            <label class="block text-gray-300 font-bold mb-1">VIP ৫-১০ পুরস্কার:</label>
                            <input type="number" name="golden_egg_tier2" value="<?= $settings['golden_egg_tier2'] ?? 99 ?>" class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white font-mono font-bold">
                        </div>
                        <div>
                            <label class="block text-gray-300 font-bold mb-1">VIP ১১+ পুরস্কার:</label>
                            <input type="number" name="golden_egg_tier3" value="<?= $settings['golden_egg_tier3'] ?? 199 ?>" class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white font-mono font-bold">
                        </div>
                    </div>
                </div>

                <!-- 2. Lucky Spin Wheel Control -->
                <div class="bg-black/40 p-4 rounded-2xl border border-red-500/30 space-y-3">
                    <h3 class="text-sm font-bold text-rose-400 flex items-center gap-1.5">
                        <span>🎡 ২. লাকি স্পিন হুইল ও কাউন্টডাউন টাইমার (IMG_0276)</span>
                    </h3>
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                        <div>
                            <label class="block text-gray-300 font-bold mb-1">কাউন্টডাউন সময় (সময় এড):</label>
                            <input type="text" name="wheel_countdown_timer" value="<?= htmlspecialchars($settings['wheel_countdown_timer'] ?? '২৩ : ০৬ : ৩১') ?>" class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white font-mono font-bold">
                        </div>
                        <div>
                            <label class="block text-gray-300 font-bold mb-1">VIP ১-৪ ড্র প্রাইজ:</label>
                            <input type="number" name="wheel_tier1" value="<?= $settings['wheel_tier1'] ?? 8 ?>" class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white font-mono font-bold">
                        </div>
                        <div>
                            <label class="block text-gray-300 font-bold mb-1">VIP ৫-১০ ড্র প্রাইজ:</label>
                            <input type="number" name="wheel_tier2" value="<?= $settings['wheel_tier2'] ?? 88 ?>" class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white font-mono font-bold">
                        </div>
                        <div>
                            <label class="block text-gray-300 font-bold mb-1">VIP ১১+ মেগা প্রাইজ:</label>
                            <input type="number" name="wheel_tier3" value="<?= $settings['wheel_tier3'] ?? 1888 ?>" class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white font-mono font-bold">
                        </div>
                    </div>
                </div>

                <!-- 3. Red Packet & Rescue Fund -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="bg-black/40 p-4 rounded-2xl border border-rose-500/30 space-y-3">
                        <h3 class="text-sm font-bold text-rose-300">🧧 ৩. রেড প্যাকেট (IMG_0275)</h3>
                        <div class="text-xs">
                            <label class="block text-gray-300 font-bold mb-1">দৈনিক রেড প্যাকেট সংখ্যা:</label>
                            <input type="number" name="red_packet_daily_limit" value="<?= $settings['red_packet_daily_limit'] ?? 17 ?>" class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white font-mono font-bold">
                        </div>
                    </div>

                    <div class="bg-black/40 p-4 rounded-2xl border border-emerald-500/30 space-y-3">
                        <h3 class="text-sm font-bold text-emerald-300">🛡️ ৪. উদ্ধার তহবিল (Rescue Fund)</h3>
                        <div class="grid grid-cols-2 gap-2 text-xs">
                            <div>
                                <label class="block text-gray-300 font-bold mb-1">ক্যাশব্যাক হার (%):</label>
                                <input type="number" step="0.1" name="rescue_fund_percentage" value="<?= $settings['rescue_fund_percentage'] ?? 10.0 ?>" class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white font-mono font-bold">
                            </div>
                            <div>
                                <label class="block text-gray-300 font-bold mb-1">দৈনিক সর্বোচ্চ সীমা:</label>
                                <input type="number" name="rescue_fund_daily_max" value="<?= $settings['rescue_fund_daily_max'] ?? 500.0 ?>" class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white font-mono font-bold">
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        <?php endif; ?>

        <!-- TAB: MEDIA & BRANDING (Image Link & File Upload for Everything) -->
        <?php if ($tab === 'media'): ?>
            <?php
            $existingBanners = [];
            $customGames = [];
            try {
                $existingBanners = $db->query("SELECT * FROM banners ORDER BY id DESC")->fetchAll();
                $customGames = $db->query("SELECT * FROM games_meta ORDER BY updated_at DESC LIMIT 30")->fetchAll();
            } catch (Exception $e) {}
            ?>
            <div class="space-y-6">
                <!-- 1. Logo & Favicon Branding -->
                <form method="POST" enctype="multipart/form-data" class="bg-[#1a0305] p-6 rounded-3xl border border-red-900/60 shadow-xl space-y-4">
                    <input type="hidden" name="save_media_branding" value="1">
                    <div class="flex justify-between items-center border-b border-white/10 pb-3">
                        <div>
                            <h3 class="text-sm font-black text-yellow-300 flex items-center gap-2">
                                <span>🎨 ১. ব্র্যান্ডিং লোগো ও ফেভিকন সেটিংস</span>
                            </h3>
                            <p class="text-xs text-gray-400">প্রতিটি ছবির জন্য সরাসরি ছবির লিংক (URL) অথবা আপনার কম্পিউটার/মোবাইল থেকে ফাইল আপলোড করুন</p>
                        </div>
                        <button type="submit" class="px-4 py-2 bg-gradient-to-r from-amber-400 to-yellow-400 text-black font-black text-xs rounded-xl shadow-lg hover:brightness-110 cursor-pointer">
                            সংরক্ষণ করুন ✓
                        </button>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                        <!-- Site Logo -->
                        <div class="bg-black/40 p-4 rounded-2xl border border-white/10 space-y-2">
                            <label class="block text-gray-200 font-bold">ওয়েবসাইট লোগো (Site Logo):</label>
                            <div class="flex items-center gap-3">
                                <?php $logoSrc = !empty($settings['site_logo_url']) ? $settings['site_logo_url'] : 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=200&auto=format&fit=crop&q=80'; ?>
                                <img src="<?= htmlspecialchars($logoSrc) ?>" alt="Logo Preview" class="h-10 w-24 object-contain bg-black/60 p-1 rounded-lg border border-white/20">
                                <span class="text-[11px] text-gray-400">বর্তমান লোগো প্রিভিউ</span>
                            </div>
                            <div>
                                <span class="text-[10px] text-gray-400 font-bold">ছবির লিংক (URL):</span>
                                <input type="text" name="site_logo_url" value="<?= htmlspecialchars($settings['site_logo_url'] ?? '') ?>" placeholder="https://domain.com/logo.png" class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white font-mono text-xs">
                            </div>
                            <div>
                                <span class="text-[10px] text-yellow-300 font-bold">অথবা সরাসরি ফাইল আপলোড করুন:</span>
                                <input type="file" name="site_logo_file" accept="image/*" class="w-full text-xs text-gray-400 file:mr-2 file:py-1 file:px-2.5 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-yellow-400 file:text-black hover:file:bg-yellow-300 cursor-pointer">
                            </div>
                        </div>

                        <!-- Site Favicon -->
                        <div class="bg-black/40 p-4 rounded-2xl border border-white/10 space-y-2">
                            <label class="block text-gray-200 font-bold">ওয়েবসাইট ফেভিকন (Site Favicon):</label>
                            <div class="flex items-center gap-3">
                                <?php $favSrc = !empty($settings['site_favicon_url']) ? $settings['site_favicon_url'] : 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?w=100&auto=format&fit=crop&q=80'; ?>
                                <img src="<?= htmlspecialchars($favSrc) ?>" alt="Favicon Preview" class="w-8 h-8 object-cover rounded-lg border border-white/20">
                                <span class="text-[11px] text-gray-400">বর্তমান ফেভিকন প্রিভিউ</span>
                            </div>
                            <div>
                                <span class="text-[10px] text-gray-400 font-bold">ছবির লিংক (URL):</span>
                                <input type="text" name="site_favicon_url" value="<?= htmlspecialchars($settings['site_favicon_url'] ?? '') ?>" placeholder="https://domain.com/favicon.ico" class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white font-mono text-xs">
                            </div>
                            <div>
                                <span class="text-[10px] text-yellow-300 font-bold">অথবা সরাসরি ফাইল আপলোড করুন:</span>
                                <input type="file" name="site_favicon_file" accept="image/*" class="w-full text-xs text-gray-400 file:mr-2 file:py-1 file:px-2.5 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-yellow-400 file:text-black hover:file:bg-yellow-300 cursor-pointer">
                            </div>
                        </div>
                    </div>

                    <!-- 2. Event Promotions Graphics -->
                    <div class="border-t border-white/10 pt-4">
                        <h4 class="text-xs font-black text-yellow-300 mb-3">🎁 ২. প্রমোশন ও ইভেন্ট গ্রাফিক্স (লিংক ও আপলোড)</h4>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                            <!-- Golden Egg -->
                            <div class="bg-black/40 p-3 rounded-2xl border border-yellow-500/30 space-y-2">
                                <label class="block text-yellow-400 font-bold">🥚 গোল্ডেন এগ আর্ট (Golden Egg - IMG_0284):</label>
                                <?php $eggSrc = !empty($settings['golden_egg_img']) ? $settings['golden_egg_img'] : 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=300&auto=format&fit=crop&q=80'; ?>
                                <img src="<?= htmlspecialchars($eggSrc) ?>" class="h-16 w-full object-cover rounded-xl border border-white/10">
                                <input type="text" name="golden_egg_img" value="<?= htmlspecialchars($settings['golden_egg_img'] ?? '') ?>" placeholder="ছবির লিংক (URL)" class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white text-xs">
                                <input type="file" name="golden_egg_file" accept="image/*" class="w-full text-xs text-gray-400 file:mr-2 file:py-1 file:px-2.5 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-yellow-400 file:text-black cursor-pointer">
                            </div>

                            <!-- Red Packet -->
                            <div class="bg-black/40 p-3 rounded-2xl border border-rose-500/30 space-y-2">
                                <label class="block text-rose-400 font-bold">🧧 রেড প্যাকেট আর্ট (Red Packet - IMG_0275):</label>
                                <?php $redSrc = !empty($settings['red_packet_img']) ? $settings['red_packet_img'] : 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?w=300&auto=format&fit=crop&q=80'; ?>
                                <img src="<?= htmlspecialchars($redSrc) ?>" class="h-16 w-full object-cover rounded-xl border border-white/10">
                                <input type="text" name="red_packet_img" value="<?= htmlspecialchars($settings['red_packet_img'] ?? '') ?>" placeholder="ছবির লিংক (URL)" class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white text-xs">
                                <input type="file" name="red_packet_file" accept="image/*" class="w-full text-xs text-gray-400 file:mr-2 file:py-1 file:px-2.5 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-rose-400 file:text-black cursor-pointer">
                            </div>

                            <!-- Lucky Wheel -->
                            <div class="bg-black/40 p-3 rounded-2xl border border-amber-500/30 space-y-2">
                                <label class="block text-amber-400 font-bold">🎡 লাকি স্পিন হুইল আর্ট (Lucky Wheel - IMG_0276):</label>
                                <?php $wheelSrc = !empty($settings['wheel_img']) ? $settings['wheel_img'] : 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=300&auto=format&fit=crop&q=80'; ?>
                                <img src="<?= htmlspecialchars($wheelSrc) ?>" class="h-16 w-full object-cover rounded-xl border border-white/10">
                                <input type="text" name="wheel_img" value="<?= htmlspecialchars($settings['wheel_img'] ?? '') ?>" placeholder="ছবির লিংক (URL)" class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white text-xs">
                                <input type="file" name="wheel_file" accept="image/*" class="w-full text-xs text-gray-400 file:mr-2 file:py-1 file:px-2.5 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-amber-400 file:text-black cursor-pointer">
                            </div>

                            <!-- Rescue Relief Fund -->
                            <div class="bg-black/40 p-3 rounded-2xl border border-emerald-500/30 space-y-2">
                                <label class="block text-emerald-400 font-bold">🛡️ উদ্ধার তহবিল আর্ট (Rescue Fund):</label>
                                <?php $rescueSrc = !empty($settings['rescue_fund_img']) ? $settings['rescue_fund_img'] : 'https://images.unsplash.com/photo-1579621970795-87facc2f976d?w=300&auto=format&fit=crop&q=80'; ?>
                                <img src="<?= htmlspecialchars($rescueSrc) ?>" class="h-16 w-full object-cover rounded-xl border border-white/10">
                                <input type="text" name="rescue_fund_img" value="<?= htmlspecialchars($settings['rescue_fund_img'] ?? '') ?>" placeholder="ছবির লিংক (URL)" class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white text-xs">
                                <input type="file" name="rescue_fund_file" accept="image/*" class="w-full text-xs text-gray-400 file:mr-2 file:py-1 file:px-2.5 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-emerald-400 file:text-black cursor-pointer">
                            </div>
                        </div>
                    </div>
                </form>

                <!-- 3. Promotional Carousel Banners Manager -->
                <div class="bg-[#1a0305] p-6 rounded-3xl border border-red-900/60 shadow-xl space-y-4">
                    <div>
                        <h3 class="text-sm font-black text-yellow-300">🖼️ ৩. হোম স্লাইডার ব্যানার ম্যানেজার (নতুন ব্যানার যুক্ত ও ডিলিট)</h3>
                        <p class="text-xs text-gray-400">প্রতিটি ব্যানারের জন্য সরাসরি ছবির লিংক অথবা ফাইল আপলোড অপশন রয়েছে</p>
                    </div>

                    <!-- Add Banner Form -->
                    <form method="POST" enctype="multipart/form-data" class="bg-black/50 p-4 rounded-2xl border border-yellow-500/30 space-y-3 text-xs">
                        <input type="hidden" name="add_banner" value="1">
                        <span class="font-bold text-amber-300 block">নতুন ব্যানার যোগ করুন:</span>
                        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                            <div>
                                <label class="block text-gray-300 mb-1">ব্যানার ব্যাজ:</label>
                                <input type="text" name="banner_badge" placeholder="যেমন: নতুন প্লেয়ার অফার" class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white">
                            </div>
                            <div>
                                <label class="block text-gray-300 mb-1">শিরোনাম ১ (Title 1):</label>
                                <input type="text" name="banner_title1" placeholder="যেমন: ১০০% প্রথম ডিপোজিট" class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white">
                            </div>
                            <div>
                                <label class="block text-gray-300 mb-1">শিরোনাম ২ (Title 2):</label>
                                <input type="text" name="banner_title2" placeholder="যেমন: দ্বিগুণ ক্যাশ রিওয়ার্ড" class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white">
                            </div>
                            <div>
                                <label class="block text-gray-300 mb-1">অ্যামাউন্ট/প্রাইজ:</label>
                                <input type="text" name="banner_amount" placeholder="যেমন: ৳১০,০০০" class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white">
                            </div>
                            <div>
                                <label class="block text-gray-300 mb-1">বাটন টেক্সট:</label>
                                <input type="text" name="banner_btn_text" value="এখনই ডিপোজিট করুন" class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white">
                            </div>
                            <div>
                                <label class="block text-gray-300 mb-1">অ্যাকশন টার্গেট:</label>
                                <select name="banner_action" class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white">
                                    <option value="deposit">ডিপোজিট উইন্ডো (Deposit)</option>
                                    <option value="withdraw">উত্তোলন উইন্ডো (Withdraw)</option>
                                    <option value="egg">গোল্ডেন এগ (Golden Egg)</option>
                                    <option value="wheel">লাকি স্পিন হুইল (Lucky Wheel)</option>
                                    <option value="red_packet">রেড প্যাকেট (Red Packet)</option>
                                </select>
                            </div>
                        </div>

                        <!-- Image URL & File Upload for Banner -->
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                            <div>
                                <label class="block text-gray-300 mb-1">ছবির লিংক (Image URL):</label>
                                <input type="text" name="banner_img_url" placeholder="https://images.unsplash.com/photo-..." class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white">
                            </div>
                            <div>
                                <label class="block text-yellow-300 mb-1">অথবা ব্যানার ফাইল আপলোড করুন:</label>
                                <input type="file" name="banner_file" accept="image/*" class="w-full text-xs text-gray-400 file:mr-2 file:py-1 file:px-2.5 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-yellow-400 file:text-black cursor-pointer">
                            </div>
                        </div>

                        <button type="submit" class="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-xl cursor-pointer">
                            + ব্যানার যুক্ত করুন
                        </button>
                    </form>

                    <!-- Existing Banners List -->
                    <div class="space-y-2">
                        <span class="text-xs font-bold text-gray-300">বর্তমান ব্যানারসমূহ:</span>
                        <?php if (empty($existingBanners)): ?>
                            <p class="text-xs text-gray-500 py-3">ডিফল্ট ব্যানারগুলো সক্রিয় রয়েছে। কাস্টম ব্যানার যোগ করতে উপরের ফরমটি পূরণ করুন।</p>
                        <?php else: ?>
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                <?php foreach ($existingBanners as $eb): ?>
                                    <div class="bg-black/60 p-3 rounded-2xl border border-white/10 flex items-center justify-between gap-3 text-xs">
                                        <div class="flex items-center gap-3">
                                            <img src="<?= htmlspecialchars($eb['image_url']) ?>" alt="Banner" class="w-16 h-12 object-cover rounded-xl border border-white/10">
                                            <div>
                                                <span class="text-amber-400 font-bold block"><?= htmlspecialchars($eb['badge']) ?></span>
                                                <span class="text-white font-bold block"><?= htmlspecialchars($eb['title1']) ?> <?= htmlspecialchars($eb['title2']) ?></span>
                                                <span class="text-[10px] text-gray-400"><?= htmlspecialchars($eb['amount']) ?></span>
                                            </div>
                                        </div>
                                        <form method="POST" onsubmit="return confirm('আপনি কি নিশ্চিত যে এই ব্যানারটি মুছে ফেলতে চান?');">
                                            <input type="hidden" name="delete_banner" value="1">
                                            <input type="hidden" name="banner_id" value="<?= $eb['id'] ?>">
                                            <button type="submit" class="px-3 py-1 bg-red-600/80 hover:bg-red-600 text-white font-bold rounded-lg cursor-pointer">মুছুন</button>
                                        </form>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- 4. Game Thumbnails Manager -->
                <div class="bg-[#1a0305] p-6 rounded-3xl border border-red-900/60 shadow-xl space-y-4">
                    <div>
                        <h3 class="text-sm font-black text-yellow-300">🎰 ৪. গেম থাম্বনেইল ও আরটিপি (RTP) ম্যানেজার</h3>
                        <p class="text-xs text-gray-400">যেকোনো গেমের থাম্বনেইল ছবি লিংক বা ফাইল আপলোড দ্বারা পরিবর্তন করুন</p>
                    </div>

                    <form method="POST" enctype="multipart/form-data" class="bg-black/50 p-4 rounded-2xl border border-white/10 space-y-3 text-xs">
                        <input type="hidden" name="save_game_thumb" value="1">
                        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                            <div>
                                <label class="block text-gray-300 mb-1">গেম নির্বাচন বা গেম ID:</label>
                                <input type="text" name="game_id" list="game_id_presets" placeholder="super_ace" required class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white font-mono">
                                <datalist id="game_id_presets">
                                    <option value="super_ace">Super Ace</option>
                                    <option value="fortune_gems">Fortune Gems</option>
                                    <option value="flyx">FlyX Cash Crash</option>
                                    <option value="happy_fishing">Happy Fishing</option>
                                    <option value="crazy_777">Crazy 777</option>
                                    <option value="roma_x">Roma X</option>
                                    <option value="mines">Mines Daredevil</option>
                                    <option value="dragon_treasure">Dragon Treasure</option>
                                </datalist>
                            </div>
                            <div>
                                <label class="block text-gray-300 mb-1">গেমের নাম (Display Name):</label>
                                <input type="text" name="game_name" placeholder="Super Ace" required class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white">
                            </div>
                            <div>
                                <label class="block text-gray-300 mb-1">প্রোভাইডার (Provider):</label>
                                <select name="game_provider" class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white">
                                    <option value="JILI">JILI Games</option>
                                    <option value="PG Soft">PG Soft</option>
                                    <option value="Spribe">Spribe (Aviator)</option>
                                    <option value="FC">Fa Chai (FC)</option>
                                    <option value="Pragmatic">Pragmatic Play</option>
                                    <option value="JDB">JDB Gaming</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-gray-300 mb-1">RTP রেট (%):</label>
                                <input type="number" step="0.1" name="game_rtp" value="97.5" class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white">
                            </div>
                            <div>
                                <label class="block text-gray-300 mb-1">ছবির লিংক (Image URL):</label>
                                <input type="text" name="game_img_url" placeholder="https://..." class="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-white">
                            </div>
                            <div>
                                <label class="block text-yellow-300 mb-1">অথবা থাম্বনেইল ফাইল আপলোড:</label>
                                <input type="file" name="game_file" accept="image/*" class="w-full text-xs text-gray-400 file:mr-2 file:py-1 file:px-2.5 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-yellow-400 file:text-black cursor-pointer">
                            </div>
                        </div>

                        <button type="submit" class="px-5 py-2 bg-gradient-to-r from-amber-400 to-yellow-400 text-black font-black rounded-xl cursor-pointer hover:brightness-110">
                            গেমের থাম্বনেইল ও তথ্য সংরক্ষণ করুন ✓
                        </button>
                    </form>
                </div>
            </div>
        <?php endif; ?>

        <!-- TAB: SOFTAGGREGATOR & WALLET CALLBACK URL (PDF Documentation 100% Compliant) -->
        <?php if ($tab === 'softaggregator'): ?>
            <div class="space-y-6">
                <!-- Callback URL Banner Card -->
                <div class="bg-gradient-to-r from-[#240306] via-[#3a060d] to-[#240306] border-2 border-yellow-500/50 p-5 rounded-3xl shadow-2xl space-y-3">
                    <div class="flex items-center gap-2">
                        <span class="text-2xl">🔗</span>
                        <div>
                            <h2 class="text-base font-black text-yellow-300">অফিসিয়াল SoftAggregator Seamless Wallet Callback URL</h2>
                            <p class="text-xs text-gray-300">SoftAggregator প্রোভাইডার ড্যাশবোর্ডে নিচের যেকোনো একটি লিংক যুক্ত করুন</p>
                        </div>
                    </div>

                    <div class="space-y-2">
                        <div>
                            <span class="text-[11px] font-bold text-gray-400 block mb-1">প্রাইমারি কলব্যাক ইউআরএল (Primary Callback URL):</span>
                            <div class="p-3 bg-black/80 rounded-xl border border-yellow-500/40 flex items-center justify-between gap-2">
                                <code class="font-mono text-yellow-300 text-xs break-all select-all">
                                    <?= (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] ?>/api/softaggregator_callback.php
                                </code>
                                <button onclick="navigator.clipboard.writeText(this.previousElementSibling.innerText.trim()); alert('কলব্যাক ইউআরএল কপি করা হয়েছে!');" class="shrink-0 px-3 py-1 bg-amber-400 text-black font-black text-xs rounded-lg hover:bg-amber-300 cursor-pointer">কপি করুন</button>
                            </div>
                        </div>

                        <div>
                            <span class="text-[11px] font-bold text-gray-400 block mb-1">সংক্ষিপ্ত অল্টারনেটিভ লিংক (Short Alias):</span>
                            <div class="p-3 bg-black/80 rounded-xl border border-white/10 flex items-center justify-between gap-2">
                                <code class="font-mono text-gray-300 text-xs break-all select-all">
                                    <?= (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] ?>/callback.php
                                </code>
                                <button onclick="navigator.clipboard.writeText(this.previousElementSibling.innerText.trim()); alert('শর্ট লিংক কপি করা হয়েছে!');" class="shrink-0 px-3 py-1 bg-gray-700 text-white font-bold text-xs rounded-lg hover:bg-gray-600 cursor-pointer">কপি করুন</button>
                            </div>
                        </div>
                    </div>

                    <!-- PDF Rules Checklist -->
                    <div class="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2 text-[11px] border-t border-white/10">
                        <div class="flex items-center gap-1.5 text-emerald-400">
                            <span>✓</span>
                            <span>GET রিকোয়েস্ট & HTTP 200 রেসপন্স</span>
                        </div>
                        <div class="flex items-center gap-1.5 text-emerald-400">
                            <span>✓</span>
                            <span>পূর্ণ সংখ্যায় Cents ফরম্যাট (৳500 = 50000)</span>
                        </div>
                        <div class="flex items-center gap-1.5 text-emerald-400">
                            <span>✓</span>
                            <span>MD5(timestamp + salt_key) ভ্যালিডেশন</span>
                        </div>
                    </div>
                </div>

                <!-- API Credentials Settings Form -->
                <form method="POST" class="bg-[#1a0305] p-6 rounded-3xl border border-red-900/60 shadow-xl space-y-4">
                    <input type="hidden" name="save_softaggregator" value="1">
                    <div class="flex justify-between items-center border-b border-white/10 pb-3">
                        <div>
                            <h3 class="text-sm font-black text-yellow-300">🔑 SoftAggregator API ক্রেডেনশিয়ালস</h3>
                            <p class="text-xs text-gray-400">SoftAggregator থেকে প্রাপ্ত API Login ও Salt Key প্রদান করুন</p>
                        </div>
                        <button type="submit" class="px-4 py-2 bg-gradient-to-r from-amber-400 to-yellow-400 text-black font-black text-xs rounded-xl shadow-lg hover:brightness-110 cursor-pointer">
                            সংরক্ষণ করুন ✓
                        </button>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                        <div>
                            <label class="block text-gray-300 font-bold mb-1">API Login (api_login):</label>
                            <input type="text" name="softaggregator_api_login" value="<?= htmlspecialchars($settings['softaggregator_api_login'] ?? 'DEMO_LIVEXWIN_LOGIN') ?>" class="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-white font-mono font-bold">
                        </div>
                        <div>
                            <label class="block text-gray-300 font-bold mb-1">API Password (api_password):</label>
                            <input type="password" name="softaggregator_api_password" value="<?= htmlspecialchars($settings['softaggregator_api_password'] ?? 'DEMO_LIVEXWIN_PASS') ?>" class="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-white font-mono font-bold">
                        </div>
                        <div>
                            <label class="block text-gray-300 font-bold mb-1">Salt Key (md5 সাইন কি):</label>
                            <input type="text" name="softaggregator_salt_key" value="<?= htmlspecialchars($settings['softaggregator_salt_key'] ?? 'LXW_SALT_KEY_88273619') ?>" class="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-white font-mono font-bold">
                        </div>
                        <div class="grid grid-cols-2 gap-2">
                            <div>
                                <label class="block text-gray-300 font-bold mb-1">মুদ্রা (Currency):</label>
                                <input type="text" name="softaggregator_currency" value="<?= htmlspecialchars($settings['softaggregator_currency'] ?? 'BDT') ?>" class="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-white font-mono font-bold">
                            </div>
                            <div>
                                <label class="block text-gray-300 font-bold mb-1">দেশ (Country):</label>
                                <input type="text" name="softaggregator_country" value="<?= htmlspecialchars($settings['softaggregator_country'] ?? 'BD') ?>" class="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-white font-mono font-bold">
                            </div>
                        </div>
                    </div>
                </form>

                <!-- Live Callback Simulator & Tester -->
                <div class="bg-[#1a0305] p-6 rounded-3xl border border-red-900/60 shadow-xl space-y-4">
                    <div>
                        <h3 class="text-sm font-black text-yellow-300 flex items-center gap-1.5">
                            <span>🧪 লাইভ কলব্যাক সিমুলেটর ও টেস্ট টুল</span>
                        </h3>
                        <p class="text-xs text-gray-400">SoftAggregator এর balance, debit, ও credit কলব্যাক পরীক্ষা করুন</p>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
                        <div>
                            <label class="block text-gray-300 font-bold mb-1">অ্যাকশন টাইপ:</label>
                            <select id="simAction" class="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-white font-bold">
                                <option value="balance">balance (ব্যালেন্স চেক)</option>
                                <option value="debit">debit (বেট কাটা)</option>
                                <option value="credit">credit (উইন ক্রেডিট)</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-gray-300 font-bold mb-1">প্লেয়ার ইউজারনেম:</label>
                            <input type="text" id="simUser" value="demo_player" class="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-white font-mono font-bold">
                        </div>
                        <div>
                            <label class="block text-gray-300 font-bold mb-1">টাকার পরিমাণ (৳ BDT):</label>
                            <input type="number" id="simAmount" value="50" class="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-white font-mono font-bold">
                        </div>
                        <div class="flex items-end">
                            <button onclick="testCallback()" class="w-full py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:brightness-110 text-black font-black text-xs rounded-xl shadow cursor-pointer">
                                টেস্ট রান করুন ⚡
                            </button>
                        </div>
                    </div>

                    <!-- Simulator Output -->
                    <div id="simResult" class="p-3 bg-black/80 rounded-xl border border-white/10 text-xs font-mono text-gray-300 hidden">
                        <div class="flex justify-between items-center mb-1">
                            <span class="text-[10px] text-gray-400">API রেসপন্স পে-লোড:</span>
                            <span id="simStatus" class="px-2 py-0.5 rounded text-[10px] font-bold"></span>
                        </div>
                        <pre id="simJson" class="text-emerald-400 whitespace-pre overflow-x-auto"></pre>
                    </div>

                    <script>
                        async function testCallback() {
                            const act = document.getElementById('simAction').value;
                            const user = document.getElementById('simUser').value;
                            const amt = document.getElementById('simAmount').value;
                            const amtCents = Math.round(parseFloat(amt || 0) * 100);
                            const url = '../api/softaggregator_callback.php?action=' + act + '&username=' + encodeURIComponent(user) + '&amount=' + amtCents + '&currency=BDT&call_id=sim_' + Date.now() + '&key=test_bypass';

                            try {
                                const res = await fetch(url);
                                const json = await res.json();
                                document.getElementById('simResult').classList.remove('hidden');
                                document.getElementById('simJson').innerText = JSON.stringify(json, null, 2);
                                const badge = document.getElementById('simStatus');
                                if (json.error === 0) {
                                    badge.className = 'px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-500/40';
                                    badge.innerText = 'HTTP 200 OK (Error 0)';
                                } else {
                                    badge.className = 'px-2 py-0.5 rounded text-[10px] font-bold bg-rose-950 text-rose-300 border border-rose-500/40';
                                    badge.innerText = 'Error Code: ' + json.error;
                                }
                            } catch(err) {
                                document.getElementById('simResult').classList.remove('hidden');
                                document.getElementById('simJson').innerText = 'Request failed: ' + err.message;
                            }
                        }
                    </script>
                </div>
            </div>
        <?php endif; ?>

        <!-- TAB: WITHDRAWALS -->
        <?php if ($tab === 'withdrawals'): ?>
            <div class="bg-[#1a0305] p-5 rounded-3xl border border-red-900/60 shadow-xl space-y-3">
                <h3 class="text-base font-black text-white">অনুমোদনাধীন উত্তোলন অনুরোধ (<?= count($pendingWithdrawals) ?>)</h3>
                <?php if (empty($pendingWithdrawals)): ?>
                    <p class="text-gray-400 text-xs py-8 text-center">কোনো অপেক্ষমান উত্তোলন অনুরোধ নেই।</p>
                <?php else: ?>
                    <div class="space-y-2">
                        <?php foreach ($pendingWithdrawals as $pw): ?>
                            <div class="p-3 bg-black/50 border border-white/10 rounded-xl flex justify-between items-center text-xs">
                                <div>
                                    <span class="font-mono text-yellow-300 font-bold block"><?= $pw['id'] ?></span>
                                    <span class="text-gray-300">ইউজার ID: <?= $pw['user_id'] ?> • <?= $pw['method'] ?>: <?= $pw['account_number'] ?></span>
                                    <span class="text-[10px] text-gray-500 block"><?= $pw['created_at'] ?></span>
                                </div>
                                <div class="flex items-center gap-2">
                                    <span class="font-black text-sm text-emerald-400 font-mono">৳<?= number_format($pw['amount'], 2) ?></span>
                                    <form method="POST" class="inline">
                                        <input type="hidden" name="tx_id" value="<?= $pw['id'] ?>">
                                        <button type="submit" name="approve_tx" class="px-3 py-1 bg-emerald-600 text-white rounded-lg font-bold">অনুমোদন</button>
                                        <button type="submit" name="reject_tx" class="px-3 py-1 bg-red-600 text-white rounded-lg font-bold">বাতিল</button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <!-- TAB: OVERVIEW -->
        <?php if ($tab === 'overview'): ?>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div class="bg-[#1a0305] p-4 rounded-2xl border border-red-900/40">
                    <span class="text-xs text-gray-400 font-bold block">মোট প্লেয়ার</span>
                    <span class="text-2xl font-black text-white mt-1 block"><?= $totalUsers ?></span>
                </div>
                <div class="bg-[#1a0305] p-4 rounded-2xl border border-red-900/40">
                    <span class="text-xs text-gray-400 font-bold block">অপেক্ষমান ক্যাশআউট</span>
                    <span class="text-2xl font-black text-yellow-400 mt-1 block"><?= count($pendingWithdrawals) ?></span>
                </div>
                <div class="bg-[#1a0305] p-4 rounded-2xl border border-red-900/40">
                    <span class="text-xs text-gray-400 font-bold block">এগ সর্বোচ্চ পুরষ্কার</span>
                    <span class="text-2xl font-black text-yellow-300 mt-1 block font-mono">৳ <?= number_format($settings['golden_egg_max_display'] ?? 99999) ?></span>
                </div>
                <div class="bg-[#1a0305] p-4 rounded-2xl border border-red-900/40">
                    <span class="text-xs text-gray-400 font-bold block">উদ্ধার তহবিল হার</span>
                    <span class="text-2xl font-black text-emerald-400 mt-1 block font-mono"><?= $settings['rescue_fund_percentage'] ?? 10 ?>%</span>
                </div>
            </div>
        <?php endif; ?>

        <!-- TAB: USERS -->
        <?php if ($tab === 'users'): ?>
            <?php
            $usersList = $db->query("SELECT id, username, phone, balance, vip_level, status, created_at FROM users ORDER BY id DESC LIMIT 50")->fetchAll();
            ?>
            <div class="bg-[#1a0305] p-5 rounded-3xl border border-red-900/60 shadow-xl">
                <h3 class="text-base font-black text-white mb-3">প্লেয়ার তালিকা (সক্রিয় সদস্যগণ)</h3>
                <div class="overflow-x-auto text-xs">
                    <table class="w-full text-left">
                        <thead>
                            <tr class="border-b border-white/10 text-gray-400">
                                <th class="pb-2">ID</th>
                                <th class="pb-2">ইউজারনেম</th>
                                <th class="pb-2">ফোন</th>
                                <th class="pb-2">ব্যালেন্স</th>
                                <th class="pb-2">VIP লেভেল</th>
                                <th class="pb-2">স্ট্যাটাস</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-white/5">
                            <?php foreach ($usersList as $u): ?>
                                <tr>
                                    <td class="py-2.5 font-mono text-gray-400"><?= $u['id'] ?></td>
                                    <td class="py-2.5 font-bold text-white"><?= htmlspecialchars($u['username']) ?></td>
                                    <td class="py-2.5 font-mono text-gray-300"><?= htmlspecialchars($u['phone']) ?></td>
                                    <td class="py-2.5 font-mono font-bold text-yellow-300">৳<?= number_format($u['balance'], 2) ?></td>
                                    <td class="py-2.5 font-bold text-amber-400">VIP <?= $u['vip_level'] ?></td>
                                    <td class="py-2.5">
                                        <span class="px-2 py-0.5 rounded text-[10px] font-bold <?= $u['status'] === 'active' ? 'bg-emerald-950 text-emerald-300' : 'bg-red-950 text-red-300' ?>">
                                            <?= $u['status'] ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </main>
</body>
</html>
