-- LivexWin Casino Platform - Complete MySQL Database Schema
-- Version: 2.8.4-PHP
-- Created: 2026-11-07
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+06:00";

-- --------------------------------------------------------
-- Table: users
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL UNIQUE,
  `nickname` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `trx_password` varchar(10) DEFAULT '123456',
  `trx_password_set` tinyint(1) NOT NULL DEFAULT 1,
  `avatar` text DEFAULT NULL,
  `vip_level` int(11) NOT NULL DEFAULT 1,
  `vip_points` int(11) NOT NULL DEFAULT 0,
  `balance` decimal(14,2) NOT NULL DEFAULT 500.00,
  `frozen_balance` decimal(14,2) NOT NULL DEFAULT 0.00,
  `currency` varchar(10) NOT NULL DEFAULT 'BDT',
  `role` enum('player','admin','superadmin') NOT NULL DEFAULT 'player',
  `status` enum('active','banned') NOT NULL DEFAULT 'active',
  `golden_eggs_left` int(11) NOT NULL DEFAULT 3,
  `red_packets_claimed` int(11) NOT NULL DEFAULT 0,
  `daily_checkin_claimed` tinyint(1) NOT NULL DEFAULT 0,
  `consecutive_days` int(11) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: bound_wallets (Max 5 cards per user, permanent lock)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `bound_wallets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` enum('nagad','bkash','rocket','bank') NOT NULL,
  `account_name` varchar(100) NOT NULL,
  `account_number` varchar(50) NOT NULL,
  `is_locked` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id_idx` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: transactions
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `transactions` (
  `id` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` enum('deposit','withdraw','bonus','rebate') NOT NULL,
  `amount` decimal(14,2) NOT NULL,
  `fee` decimal(14,2) NOT NULL DEFAULT 0.00,
  `status` enum('pending','approved','rejected','completed') NOT NULL DEFAULT 'pending',
  `method` varchar(30) DEFAULT NULL,
  `channel` varchar(30) DEFAULT NULL,
  `account_number` varchar(50) DEFAULT NULL,
  `trx_id` varchar(100) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_tx_idx` (`user_id`),
  KEY `status_idx` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: bet_records (Betting History)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `bet_records` (
  `id` varchar(60) NOT NULL,
  `user_id` int(11) NOT NULL,
  `game_id` varchar(50) NOT NULL,
  `game_name` varchar(100) NOT NULL,
  `provider` varchar(50) NOT NULL,
  `bet_amount` decimal(14,2) NOT NULL,
  `payout_amount` decimal(14,2) NOT NULL,
  `profit` decimal(14,2) NOT NULL,
  `multiplier` decimal(8,2) NOT NULL DEFAULT 1.00,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_bet_idx` (`user_id`),
  KEY `date_bet_idx` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: site_settings & promotion controls
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `site_settings` (
  `id` int(11) NOT NULL DEFAULT 1,
  `site_name` varchar(100) NOT NULL DEFAULT 'LivexWin',
  `site_url` varchar(255) NOT NULL DEFAULT 'https://livexwin.com',
  `brand_tagline` varchar(255) NOT NULL DEFAULT 'Bangladesh Premier Gaming Platform',
  `min_deposit` decimal(10,2) NOT NULL DEFAULT 100.00,
  `max_deposit` decimal(10,2) NOT NULL DEFAULT 50000.00,
  `min_withdraw` decimal(10,2) NOT NULL DEFAULT 100.00,
  `max_withdraw` decimal(10,2) NOT NULL DEFAULT 25000.00,
  `golden_egg_max_display` int(11) NOT NULL DEFAULT 99999,
  `golden_egg_tier1` int(11) NOT NULL DEFAULT 9,
  `golden_egg_tier2` int(11) NOT NULL DEFAULT 99,
  `golden_egg_tier3` int(11) NOT NULL DEFAULT 199,
  `wheel_countdown_timer` varchar(30) NOT NULL DEFAULT '23:06:31',
  `wheel_tier1` int(11) NOT NULL DEFAULT 8,
  `wheel_tier2` int(11) NOT NULL DEFAULT 88,
  `wheel_tier3` int(11) NOT NULL DEFAULT 1888,
  `red_packet_daily_limit` int(11) NOT NULL DEFAULT 17,
  `rescue_fund_percentage` decimal(5,2) NOT NULL DEFAULT 10.00,
  `rescue_fund_daily_max` decimal(10,2) NOT NULL DEFAULT 500.00,
  `announcement_text` text NOT NULL,
  `site_logo_url` text DEFAULT NULL,
  `site_favicon_url` text DEFAULT NULL,
  `golden_egg_img` text DEFAULT NULL,
  `red_packet_img` text DEFAULT NULL,
  `wheel_img` text DEFAULT NULL,
  `rescue_fund_img` text DEFAULT NULL,
  `softaggregator_api_login` varchar(100) DEFAULT '',
  `softaggregator_api_password` varchar(100) DEFAULT '',
  `softaggregator_salt_key` varchar(100) DEFAULT 'LXW_SALT_KEY_88273619',
  `softaggregator_callback_url` varchar(255) DEFAULT 'https://livexwin.com/api/softaggregator_callback.php',
  `softaggregator_currency` varchar(10) DEFAULT 'BDT',
  `softaggregator_status` enum('active','demo','disabled') DEFAULT 'demo',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: banners (Promotional Carousel Banners with Image Link and Upload)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `badge` varchar(100) NOT NULL DEFAULT 'নতুন ধামাকা বোনাস',
  `title1` varchar(150) NOT NULL DEFAULT 'প্রতিটি ডিপোজিটে',
  `title2` varchar(150) NOT NULL DEFAULT 'পাবেন দ্বিগুণ ক্যাশব্যাক',
  `amount` varchar(100) NOT NULL DEFAULT 'সর্বোচ্চ ৫,০০০ ৳',
  `button_text` varchar(50) NOT NULL DEFAULT 'এখনই নিন',
  `action` varchar(50) NOT NULL DEFAULT 'deposit',
  `image_url` text NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: games_meta (Game Thumbnails and RTP control)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `games_meta` (
  `id` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `provider` varchar(50) NOT NULL,
  `image_url` text NOT NULL,
  `rtp` decimal(4,1) NOT NULL DEFAULT 97.2,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: payment_methods (Payment Gateways with Logo URL & Upload)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `payment_methods` (
  `id` varchar(30) NOT NULL,
  `name` varchar(50) NOT NULL,
  `name_bn` varchar(50) NOT NULL,
  `logo_url` text NOT NULL,
  `color` varchar(30) NOT NULL DEFAULT 'orange',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: softaggregator_calls (Idempotency and call_id de-duplication)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `softaggregator_calls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `call_id` varchar(100) NOT NULL UNIQUE,
  `username` varchar(50) NOT NULL,
  `action` varchar(20) NOT NULL,
  `amount_cents` bigint(20) NOT NULL DEFAULT 0,
  `game_id` varchar(100) DEFAULT NULL,
  `round_id` varchar(100) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `call_id_idx` (`call_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Seed Initial Admin, Player & Settings
-- --------------------------------------------------------
INSERT INTO `users` (`id`, `username`, `nickname`, `phone`, `password_hash`, `trx_password`, `role`, `balance`, `vip_level`)
VALUES
(1, 'admin', 'Super Manager', '01888888888', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '123456', 'superadmin', 999999.00, 10),
(2, 't1206248521', 't1206248521', '01712062485', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '123456', 'player', 500.00, 1)
ON DUPLICATE KEY UPDATE `username` = VALUES(`username`);

INSERT INTO `bound_wallets` (`id`, `user_id`, `type`, `account_name`, `account_number`, `is_locked`)
VALUES
(1, 2, 'nagad', 'Sakib Hasan', '01712062485', 1)
ON DUPLICATE KEY UPDATE `account_name` = VALUES(`account_name`);

INSERT INTO `site_settings` (`id`, `site_name`, `announcement_text`)
VALUES (1, 'LivexWin', '❤️ নতুন ইউজার: রেজিস্ট্রেশন রিওয়ার্ড সর্বোচ্চ ৳৬০+৳৮,৮৮৮। প্রথম রিচার্জে +১৮০% ওয়েলকাম রিওয়ার্ড। প্রতিদিনের প্রথম রিচার্জে +১০% রিওয়ার্ড।')
ON DUPLICATE KEY UPDATE `site_name` = VALUES(`site_name`);

COMMIT;
