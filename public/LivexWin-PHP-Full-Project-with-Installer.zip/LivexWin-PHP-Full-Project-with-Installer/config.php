<?php
/**
 * LivexWin Casino Platform - Core Configuration & Database Bootstrap
 */
session_start();

// Database credentials (configured by install.php or customized manually)
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DB_NAME') ?: 'livexwin_db');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');
define('DB_PORT', getenv('DB_PORT') ?: '3306');

// Site Config
define('SITE_NAME', 'LivexWin');
define('SITE_URL', (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]");
define('ADMIN_SECRET', 'LXW_ADMIN_KEY_992837');

function getDB(): ?PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        } catch (PDOException $e) {
            // Check if not installed
            if (!file_exists(__DIR__ . '/.installed') && basename($_SERVER['PHP_SELF']) !== 'install.php') {
                header('Location: install.php');
                exit;
            }
            error_log("DB Connection Error: " . $e->getMessage());
            return null;
        }
    }
    return $pdo;
}

// Helper: JSON response output
function jsonResponse(array $data, int $statusCode = 200): void {
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// Helper: Mask phone or account number (show first 3 and last 3 digits e.g. 017*****485)
function maskAccountNumber(?string $acc): string {
    if (!$acc) return '';
    $acc = trim($acc);
    $len = strlen($acc);
    if ($len <= 4) return $acc;
    $first = substr($acc, 0, 3);
    $last = substr($acc, -3);
    return $first . '*****' . $last;
}

// Helper: Get logged in user from session
function getCurrentUser(): ?array {
    if (!isset($_SESSION['user_id'])) {
        return null;
    }
    $db = getDB();
    if (!$db) return null;
    $stmt = $db->prepare("SELECT id, username, nickname, phone, avatar, vip_level, vip_points, balance, frozen_balance, currency, role, status, golden_eggs_left, red_packets_claimed, trx_password_set FROM users WHERE id = ? LIMIT 1");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch() ?: null;
}

// Helper: Load site settings
function getSiteSettings(): array {
    $db = getDB();
    if (!$db) {
        return [
            'site_name' => 'LivexWin',
            'min_deposit' => 100,
            'max_deposit' => 50000,
            'min_withdraw' => 100,
            'max_withdraw' => 25000,
            'golden_egg_max_display' => 99999,
            'golden_egg_tier1' => 9,
            'golden_egg_tier2' => 99,
            'golden_egg_tier3' => 199,
            'wheel_countdown_timer' => '23:06:31',
            'wheel_tier1' => 8,
            'wheel_tier2' => 88,
            'wheel_tier3' => 1888,
            'red_packet_daily_limit' => 17,
            'rescue_fund_percentage' => 10.0,
            'rescue_fund_daily_max' => 500.0,
        ];
    }
    $stmt = $db->query("SELECT * FROM site_settings WHERE id = 1 LIMIT 1");
    $row = $stmt->fetch();
    return $row ?: [];
}

// Helper: Handle direct file upload for admin and api (image link + file upload)
function saveUploadedImage(string $fileKey, string $targetFolder = 'uploads'): ?string {
    if (!isset($_FILES[$fileKey]) || $_FILES[$fileKey]['error'] !== UPLOAD_ERR_OK) {
        return null;
    }
    $targetDir = __DIR__ . '/' . $targetFolder . '/';
    if (!is_dir($targetDir)) {
        @mkdir($targetDir, 0755, true);
    }
    $ext = strtolower(pathinfo($_FILES[$fileKey]['name'], PATHINFO_EXTENSION));
    $allowed = ['jpg', 'jpeg', 'png', 'webp', 'svg', 'gif'];
    if (!in_array($ext, $allowed)) {
        return null;
    }
    $filename = time() . '_' . bin2hex(random_bytes(5)) . '.' . $ext;
    if (move_uploaded_file($_FILES[$fileKey]['tmp_name'], $targetDir . $filename)) {
        return $targetFolder . '/' . $filename;
    }
    return null;
}
