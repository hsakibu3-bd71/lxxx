# LivexWin - Complete Standalone PHP Casino Platform with Installer

## 🚀 Instant Deployment Guide (cPanel, hPanel, VPS, or Apache)

### Step 1: Upload and Extract
1. Upload this ZIP file to your web server (e.g., `public_html` directory on cPanel).
2. Extract all contents into the root directory.

### Step 2: Run Web Installer
1. Open your browser and navigate to:
   ```
   http://your-domain.com/install.php
   ```
2. The installer will test your PHP environment (PHP 8.0+ supported, PDO MySQL, cURL).
3. Enter your MySQL database details (host, database name, username, password).
4. Enter your custom admin password and 6-digit withdrawal PIN.
5. Click **"ইন্সটল ও ডাটাবেস তৈরি করুন ⚡"**.

### Step 3: Access
- **Website Home**: `http://your-domain.com/`
- **Master Admin Panel**: `http://your-domain.com/admin/index.php`
- **Default Admin User**: `admin`
- **Default Admin Password**: `admin123` (or whatever you set during install)
- **Default Withdrawal PIN**: `123456`

### 🎁 Platform Features Included:
1. **Golden Egg Event** (`IMG_0284`): 8 eggs grid, max display ৳99,999, VIP 1-4 = ৳9, VIP 5-10 = ৳99, VIP 11+ = ৳199.
2. **Red Packet Event** (`IMG_0275`): Crown ribbon "পুরস্কার", 00:00-03:00 cash rain, live winner ticker.
3. **Lucky Wheel Event** (`IMG_0276`): iPhone 18 Pro Max, countdown timer (configurable from admin).
4. **Rescue Relief Fund (উদ্ধার তহবিল)**: 10% daily emergency cashback.
5. **My Cards (আমার কার্ড)**: Max 5 locked cards, cannot be edited/deleted, masked last 3 digits (`017*****485`).
6. **Mandatory 6-digit Withdrawal PIN**: Enforced on every cashout request.
7. **Betting History**: Filterable by All/Win/Loss with turnover summary.
8. **Seamless Wallet Provider API**: Compatible with JILI, PG Soft, Pragmatic Play, JDB.

©2026 livexwin.com - All Rights Reserved.
